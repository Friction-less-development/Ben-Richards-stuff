//Be sure to compiler with -lpthread

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
//stat/readdir
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
//threads
#include <pthread.h>
//time
#include <time.h>
//booleans
typedef enum { false, true } bool;
//structs
struct room
{
  int id;
  char* name;
  char* type;
  int numOutboundConnections;
  struct room* outboundConnections[6];
  int outboundConnectionsIds[6];
};
struct routeStop {
    char* name;
};
//vars
struct room roomList[7];    //Array of the rooms.
int currentRoom = -1;   //What the current room the users is in is.
int inputLength = 25;   //const. How many chars the user can type.
int steps = 0;        //Steps the user took.
struct routeStop* route;    //The route
int currentRouteSize = 10; //Current size of the route array
int routeIncrementSize = 10; //How much to increment the route when it gets full.
pthread_t timeId;           //Id of the thread we use to write the time
pthread_mutex_t lock;
FILE *timeFile;             //File we use for the time txt
char timeFileName[20] = "currentTime.txt";



//Functions
void readInData();            //Reads in data from the file system to the variables
void ConnectRoom(int, int);   //Connects two rooms by id by adding a pointer the second room to the first rooms connection list.
void printCurentLocation();   //Prints the current location to the users
int isValidInput(char[inputLength]);  //Checks to see if input is valid.
int findIndexWithId(int id);  //Finds the index of a room in the roomList array by it's id.
bool isWinning();             //Checks to see if the users is in the end_room
void enlargeRouteArray();     //Enlarges the route array.
void* printTime();            //Writes the time to a file


int main(){
  //INITIALIZE MUTEX
  if (pthread_mutex_init(&lock, NULL) != 0) {
      printf("\n Mutex Init Failed\n");
      return 1;
  }
  //INITIALIZE ROUTE
  route = calloc(currentRouteSize, sizeof(struct routeStop));
  //INITIALIZE DATA
  readInData();
  int i;
  for(i=0;i<7;i++){ //Set Start room.
    if(strcmp(roomList[i].type, "START_ROOM") == 0){
      currentRoom = i;
    }
  }
  bool isPlaying = true;
  char input[inputLength];
  int result;
  while(isPlaying){
    if(isWinning() == true){  //Has won. Print winning screen and end game.
      printf("YOU HAVE FOUND THE END ROOM. CONGRATULATIONS!\n");
      //Prints out number of steps.
      printf("YOU TOOK ");
      char numSteps[5];
      snprintf(numSteps, 10, "%d", steps);
      printf(numSteps); fflush(stdout);
      printf(" STEPS. YOUR PATH TO VICTORY WAS:");
      //Prints out route to victory.
      route[steps].name = roomList[currentRoom].name; //Adds the last room to route.
      int j;
      for(j=0;j<=steps;j++){
        printf(route[j].name);
        printf("\n");
      }
      //Stops the game.
      isPlaying = false;
    } else {
      printCurentLocation();  //Prints the current location.
      printf("WHERE TO? >");
      fgets(input,inputLength,stdin);   //Gets input
      result = isValidInput(input);   //Checks to see if input is valid option.
      if(result != -1){                 //If it is valid.
        if(result == -2){               //time function called.
          //Creates thread which writes to file.
          pthread_mutex_unlock(&lock);
          int threadId;
          int err = pthread_create(&(timeId), NULL, printTime, NULL);
          if(err != 0){
            printf("error making thread");
          }

          pthread_join(timeId, NULL); //Wait for thread to complete
          //Reads from the file that was created.
          timeFile = fopen(timeFileName, "r"); // open the file to read
          struct stat dirAttributes;
          stat(timeFileName, &dirAttributes);
          char fileInfo[dirAttributes.st_size+1];
          fgets(fileInfo, dirAttributes.st_size+1, timeFile);
          printf("\n");printf(fileInfo);printf("\n\n");
          fclose (timeFile);
          pthread_mutex_lock(&lock);
        } else {
          if(steps == currentRouteSize){  //Checks to see if we need to enlarge the route array.
            enlargeRouteArray();
          }
          if(steps != 0){                 //Adds current room to route
            route[steps].name = roomList[currentRoom].name;
          }
          currentRoom = result;           //Sets the new room
          steps++;                        //Increases the step counter.
          printf("\n");
        }
      } else {                          //Was not valid input.
        printf("\nHUH? I DON’T UNDERSTAND THAT ROOM. TRY AGAIN.\n\n");
      }
    }
  }

  return 0;
}

void readInData(){
  //Following was originally copied from https://oregonstate.instructure.com/courses/1648338/pages/2-dot-4-manipulating-directories
  int newestDirTime = -1; // Modified timestamp of newest subdir examined
  char targetDirPrefix[32] = "richaben.rooms."; // Prefix we're looking for
  char newestDirName[256]; // Holds the name of the newest dir that contains prefix
  memset(newestDirName, '\0', sizeof(newestDirName));

  DIR* dirToCheck; // Holds the directory we're starting in
  struct dirent *fileInDir; // Holds the current subdir of the starting dir
  struct stat dirAttributes; // Holds information we've gained about subdir

  dirToCheck = opendir("."); // Open up the directory this program was run in

  if (dirToCheck > 0) // Make sure the current directory could be opened
  {
    while ((fileInDir = readdir(dirToCheck)) != NULL) // Check each entry in dir
    {
      if (strstr(fileInDir->d_name, targetDirPrefix) != NULL) // If entry has prefix
      {
        stat(fileInDir->d_name, &dirAttributes); // Get attributes of the entry

        if ((int)dirAttributes.st_mtime > newestDirTime) // If this time is bigger
        {
          newestDirTime = (int)dirAttributes.st_mtime;
          memset(newestDirName, '\0', sizeof(newestDirName));
          strcpy(newestDirName, fileInDir->d_name);
        }
      }
    }
  }

  closedir(dirToCheck); // Close the directory we opened

  //Now that we have the data. Read it into variables.
  DIR* newestDir = opendir(newestDirName);
  int i = 0;
  while ((fileInDir = readdir(newestDir)) != NULL) // Check each entry in dir. Each file is data for one room.
  {
    if (strstr(fileInDir->d_name, "room") != NULL){
      char* fileDir = calloc(50, sizeof(char));
      strcat(fileDir, newestDirName);
      strcat(fileDir, "/");
      strcat(fileDir, fileInDir->d_name);
      FILE *file = fopen(fileDir, "rb");
      if (file==NULL) {
        printf("FILEDIR PROBLEM AT: ");fflush(stdout); printf(fileDir);fflush(stdout); printf("\n");fflush(stdout); exit (1);
      }
      rewind(file);

      //size of file
      stat(fileDir, &dirAttributes);

      //String to read file into
      char fileInfo[dirAttributes.st_size+1];

      //Read file into string
      fgets(fileInfo, dirAttributes.st_size+1, file);
      fclose(file);

      //Set room connections to -1 to signify them as empty;
      int z;
      for(z=0;z<6;z++){
        roomList[i].outboundConnectionsIds[z] = -1;
      }
      //Use string to recreate room structs
      int k;  //THere are 5 informations to gather from the string. When k = 5 we've read them all.
      int l=0;  //Cursor to iterate through the file.
      int stringCurs = 0;
      char stringCopy[20];
      memset(stringCopy, 0, 20);

      for(k=0;k<5;l++){
        if(fileInfo[l] == '|'){
          if(k==1){
            strcpy(roomList[i].name, stringCopy);
            memset(stringCopy, 0, 20);
          } else if(k==2) {
            strcpy(roomList[i].type, stringCopy);
            memset(stringCopy, 0, 20);
          }
          k++;
          stringCurs = 0;
        } else {
          if(k==0){   //id
            int x = fileInfo[l] - '0';
            roomList[i].id = x;
          } else if(k==1){    //name
            if(roomList[i].name==NULL){
              roomList[i].name = calloc(16, sizeof(char));
            }
            stringCopy[stringCurs++] = fileInfo[l];
          } else if(k==2){    //type
            if(roomList[i].type==NULL){
              roomList[i].type = calloc(16, sizeof(char));
            }
            stringCopy[stringCurs++] = fileInfo[l];
          } else if(k==4){    //outboundids
            if(fileInfo[l] != ','){
              int x = fileInfo[l] - '0';
              roomList[i].outboundConnectionsIds[stringCurs++] = x;
            }
          }
        }
      }
      i++;
    }
  }
  //Add connection pointers.
  int k;
  for(k=0;k<7;k++){
    int j;
    for(j=0;j<6;j++){
      if(roomList[k].outboundConnectionsIds[j] != -1){
        ConnectRoom(roomList[k].id,roomList[k].outboundConnectionsIds[j]);
      }
    }
  }
}


void ConnectRoom(int roomIn, int roomToConnectTo)
{
  int i;
  for(i=0;i<7;i++){
    if(roomList[i].id == roomIn){
      int j;
      for(j=0;j<7;j++){
        if(roomList[j].id == roomToConnectTo){
          roomList[i].outboundConnections[roomList[i].numOutboundConnections] = &roomList[j];
          roomList[i].numOutboundConnections++;
        }
      }
    }
  }
}

void printCurentLocation(){
  printf("CURRENT LOCATION: ");
  printf(roomList[currentRoom].name);
  printf("\n");
  printf("POSSIBLE CONNECTIONS: ");
  int i;
  for(i=0;i<roomList[currentRoom].numOutboundConnections;i++){
    printf(roomList[currentRoom].outboundConnections[i]->name);
    if(i != roomList[currentRoom].numOutboundConnections -1){
      printf(", ");
    } else {
      printf(".\n");
    }
  }
}

int isValidInput(char input[inputLength]){
  char* stringCopy = calloc(inputLength, sizeof(char));    //This section cleans input from the eof characters.
  int j;
  for(j=0;j<inputLength;j++){
    if(input[j+1] != '\0'){
      stringCopy[j] = input[j];
    }
  }
  if(strcmp("time", stringCopy) == 0){
    return -2;
  } else {
    //Makes sure input is a good option.
    int i;
    for(i=0;i<roomList[currentRoom].numOutboundConnections;i++){
      if(strcmp(roomList[currentRoom].outboundConnections[i]->name, stringCopy)==0){
        return findIndexWithId(roomList[currentRoom].outboundConnections[i]->id);
      }
    }
    return -1;
  }
}

int findIndexWithId(int id){
  int i;
  for(i=0;i<7; i++){
    if(roomList[i].id == id){
      return i;
    }
  }
}

bool isWinning(){
  if(strcmp(roomList[currentRoom].type, "END_ROOM")==0){
    return true;
  } else {
    return false;
  }
}

void enlargeRouteArray(){
  int currentRouteSize = currentRouteSize + routeIncrementSize;
  route = realloc( route, currentRouteSize * sizeof(struct routeStop) );
}


void* printTime(){
  pthread_mutex_lock(&lock);    //Lock the file pointer.
  timeFile = fopen(timeFileName, "w"); // open the file to write
  //construct the time
  time_t rawtime;
  struct tm * timeinfo;
  time ( &rawtime );
  timeinfo = localtime ( &rawtime );
  char outputText[200];
  strftime(outputText, 200, "%I:%M%p, %A, %B %d, %Y", timeinfo);
  //Print to file
  fprintf(timeFile, outputText);
  fclose(timeFile);
  pthread_mutex_unlock(&lock);      //Unlock the file pointer.
  return;
}
