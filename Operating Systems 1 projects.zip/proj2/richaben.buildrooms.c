#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
//rand
#include <time.h>
#include <stdlib.h>
//mkdir
#include <sys/stat.h>
//booleans
typedef enum { false, true } bool;

//structs
struct room
{
  int id;
  char* name;
  char* type;
  int numOutboundConnections;
  struct room* outboundConnections[6];
  int outboundConnectionsIds[6];
};

//Functions
bool IsGraphFull();
void AddRandomConnection();
struct room* GetRandomRoom();
bool CanAddConnectionFrom(struct room* x);
bool ConnectionAlreadyExists(struct room* x, struct room* y);
void ConnectRoom(struct room* x, struct room* y);
bool IsSameRoom(struct room* x, struct room* y);


char *roomNames[10] = {"Living Room", "Humming Room", "Hunting Room", "Deck Room", "Room of Wigglers", "Strumming Room", "VRoom", "Tomb Room", "Kickin' Room", "Fake Room"};
struct room roomList[7];

int main(){
  srand(time(NULL));  //INIT random
  int i;
  for(i=0; i < 7; i++){     //Make 7 rooms
    roomList[i].id = i;     //Set id
    roomList[i].name = calloc(16, sizeof(char));  //INIT name.
    while(strcmp(roomList[i].name, "") == 0){   //Get a random name. But check to make sure it's not used. If it is used reloop.
      int r = rand();
      int isUsedBool = 0;
      int j;
      char * tee = roomNames[r%10];
      for(j=0; j < i; j++){
        if(strcmp(tee, roomList[j].name) == 0){
          isUsedBool = 1;
        }
      }
      if(isUsedBool != 1){
        strcpy(roomList[i].name, tee);
      }
    }
    //Add a type. For now we set them all to "MID_ROOM"
    roomList[i].type = calloc(16, sizeof(char));
    strcpy(roomList[i].type, "MID_ROOM");
    roomList[i].numOutboundConnections = 0; //
  }
  //Since names were randomized the following 2 assignments are effectively random
  strcpy(roomList[0].type, "START_ROOM");
  strcpy(roomList[6].type, "END_ROOM");

//Populates rooms with 3-6 connections.
  while (IsGraphFull() == false)
  {
    AddRandomConnection();
  }
  for(i=0; i < 7; i++){
    int j;
    for(j=0; j < 6; j++){
      if(roomList[i].outboundConnections[j] != NULL){
        roomList[i].outboundConnectionsIds[j] = roomList[i].outboundConnections[j]->id;
      }
    }
  }
  //Makes the directory
  char dirName[25];
  strcpy(dirName, "richaben.rooms.");
  char processId[10];
  snprintf(processId, 10, "%d", getpid());
  strcat(dirName, processId);
  mkdir(dirName, 0755);
  //Writes the files 1 by 1
  int size=sizeof(struct room);
  for(i=0;i<7;i++){
    char fileName[25];
    strcpy(fileName, dirName);
    strcat(fileName, "/room");
    char roundId[10];
    snprintf(roundId, 10, "%d", i);
    strcat(fileName, roundId);
    FILE *file = fopen(fileName, "w"); // open the file to write

    if (file != NULL) {       //Writes the file for the room. Format is {id}|{name}|{type}|{numConnections}{Ids of rooms it's connected to}
      char outputText[500] = "";
      snprintf(processId, 10, "%d", roomList[i].id);
      strcat(outputText, processId);
      strcat(outputText, "|");
      strcat(outputText, roomList[i].name);
      strcat(outputText, "|");
      strcat(outputText, roomList[i].type);
      strcat(outputText, "|");
      snprintf(processId, 10, "%d", roomList[i].numOutboundConnections);
      strcat(outputText, processId);
      strcat(outputText, "|");
      int j;
      for(j=0;j<roomList[i].numOutboundConnections;j++){
        snprintf(processId, 10, "%d", roomList[i].outboundConnectionsIds[j]);
        strcat(outputText, processId);
        if(j != roomList[i].numOutboundConnections-1){
          strcat(outputText, ",");
        }
      }
      strcat(outputText, "|");
      fprintf(file, outputText);
    } else {
      printf("Error making room files"); fflush(stdout);
      return -1;
    }
    fclose(file);
  }
  return 0;
}

// Returns true if all rooms have 3 to 6 outbound connections, false otherwise
bool IsGraphFull()
{
  int i;
  int returnValueBool = true;
  for(i=0; i < 7; i++){
    if(roomList[i].numOutboundConnections < 3){
      returnValueBool = false;
    }
  }
  return returnValueBool;
}

// Adds a random, valid outbound connection from a Room to another Room
void AddRandomConnection()
{
  struct room* A;
  struct room* B;
  while(true)
  {
    A = GetRandomRoom();

    if (CanAddConnectionFrom(A) == true)
      break;
  }
  do
  {
    B = GetRandomRoom();
  }
  while(CanAddConnectionFrom(B) == false || IsSameRoom(A, B) == true || ConnectionAlreadyExists(A, B) == true);
  ConnectRoom(A, B);
  ConnectRoom(B, A);


}

// Returns a random Room, does NOT validate if connection can be added
struct room* GetRandomRoom()
{
  int r = rand();
  return &roomList[r%7];
}

// Returns true if a connection can be added from Room x (< 6 outbound connections), false otherwise
bool CanAddConnectionFrom(struct room* x)
{
  if(x->numOutboundConnections < 6){
    return true;
  } else {
    return false;
  }
}

// Returns true if a connection from Room x to Room y already exists, false otherwise
bool ConnectionAlreadyExists(struct room* x, struct room* y)
{
  int i;
  bool returnValue = false;
  for(i=0;i<6;i++){
    if(x->outboundConnections[i] != NULL){
      if(x->outboundConnections[i]->id == y->id){
        returnValue = true;
      }
    }
  }
  return returnValue;
}

// Connects Rooms x and y together, does not check if this connection is valid
void ConnectRoom(struct room* x, struct room* y)
{
  x->outboundConnections[x->numOutboundConnections] = y;
  x->numOutboundConnections++;
}

// Returns true if Rooms x and y are the same Room, false otherwise
bool IsSameRoom(struct room* x, struct room* y)
{
  if(x->id == y->id){
    return true;
  } else {
    return false;
  }
}
