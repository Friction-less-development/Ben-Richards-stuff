#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>


int establishedConnectionFD;  //Current connection
int portNumber;               //Port number to listen on
int *backgroundPids;          //List of pids of running background processes
int backgroundPidNum = 0;     //A counter of how many background pids there are currently.

void error(const char *msg) { perror(msg); exit(1); } // Error function used for reporting issues
char * receiveMessage();        //Receives message from client
void sendMessage(char*);        //Sends message to client
void communicate();             //Handles communication with the client after making a connection
void encode(char*, char*);      //Encodes the first argument using the second argument
void removePid(int);          //Removes pid from backgroundPids variable
int addPid(int);             //Adds pid to backgroundPids variable
void handleSigchild(int);     //For removing child pids when the children terminates


int main(int argc, char *argv[]){
  int i = 0;
  //Following variables are populated on connection setup.
  int listenSocketFD;
  socklen_t sizeOfClientInfo;
  struct sockaddr_in serverAddress, clientAddress;
  backgroundPids = calloc(5, sizeof (int));   //We can only have 5 children
  signal(SIGCHLD, handleSigchild);            //Uses our custom function on child death

  if (argc < 2) {
    fprintf(stderr,"USAGE: %s port\n", argv[0]);
    exit(1);
  } // Check usage & args

  // Set up the address struct for this process (the server)
  memset((char *)&serverAddress, '\0', sizeof(serverAddress)); // Clear out the address struct
  portNumber = atoi(argv[1]); // Get the port number, convert to an integer from a string
  serverAddress.sin_family = AF_INET; // Create a network-capable socket
  serverAddress.sin_port = htons(portNumber); // Store the port number
  serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");; // Any address is allowed for connection to this process

  // Set up the socket
  listenSocketFD = socket(AF_INET, SOCK_STREAM, 0); // Create the socket
  if (listenSocketFD < 0)
    error("ERROR opening socket");// Enable the socket to begin listening
  if (bind(listenSocketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0) // Connect socket to port
    error("ERROR on binding");
  listen(listenSocketFD, 5); // Flip the socket on - it can now receive up to 5 connections


  int runLoop = 1;
  while (runLoop){
    // Accept a connection, blocking if one is not available until one connects
    sizeOfClientInfo = sizeof(clientAddress); // Get the size of the address for the client that will connect
    establishedConnectionFD = accept(listenSocketFD, (struct sockaddr *)&clientAddress, &sizeOfClientInfo); // Accept
    if ( establishedConnectionFD < 0)
      error("ERROR on accept");// Get the message from the client and display it

    if(backgroundPidNum <= 4){    //Check to make sure we have less then 5 children
      pid_t waitOn;   //For waitpid
      int status;
      pid_t processId = fork();
      if (processId == 0) { //Case child. We handle communication with the child and then exit the loop to terminate ourselves.
        communicate();
        close(establishedConnectionFD); // Close the existing socket which is connected to the client
        runLoop = 0;
      } else {// Case parent. We keep track of the child and remove it from our watchlist when the child terminates.
        do {
          waitOn = waitpid(processId, &status, WNOHANG);
          addPid(processId);
        } while (!WIFEXITED(status) && !WIFSIGNALED(status));
      }
    } else {
      printf("SERVER: Error: there are already 5 child processes. Unable to create a new one.\n");
    }
  }
  close(listenSocketFD); // Close the listening socket
  return 0;
}

void handleSigchild (int signal){
  pid_t pid;
  int status;
  //All terminated children that are in our list of background pids
  while ((pid = waitpid(-1, &status, WNOHANG)) != -1 && isBackgroundPid(pid))
  {
    //Kill process and remove it from out background process list.
    kill(pid, SIGKILL);
    removePid(pid);
  }
}

int isBackgroundPid(int pid){   //Checks if passed in int is in backgroundPid array
  int i;
  for(i=0;i<backgroundPidNum;i++){
    if(backgroundPids[i] == pid){
      return 1;
    }
  }
  return 0;
}

int addPid(int pid){   //Add background pid to an array
  if(backgroundPidNum <=4){
    backgroundPids[backgroundPidNum] = pid;
    backgroundPidNum++;
    return 1;
  } else {
    return -1;
  }
}

void removePid(int pid){  //Remove background pid from an array
  int i;
  for(i=0;i<backgroundPidNum;i++){
    if(backgroundPids[i] == pid){
      backgroundPids[i] = backgroundPids[backgroundPidNum-1];
      break;
    }
  }
  backgroundPidNum--;
  backgroundPids[backgroundPidNum-1] = -1;
}

void communicate(){ //Handles communication with the client.
  char* buffer = calloc(150000, sizeof(char));      //Will be our total message when done.
  char* readBuffer = calloc(256, sizeof(char));     //Buffer to read from client 256 chars at a time.
  memset(buffer, '\0', sizeof(buffer)); // Clear the buffer

  while (strstr(buffer, "##") == NULL) {// As long as we haven't found the terminal...
    memset(readBuffer, '\0', sizeof(readBuffer)); // Clear the buffer
    readBuffer = receiveMessage(); // Get the next chunk
    strcat(buffer, readBuffer); // Add that chunk to what we have so far
  }

  if(buffer[0] != 'e'){       //Ensure that our client is an encoding terminal. If not return error.
    char * error = calloc(75, sizeof(char));
    sprintf(error,"!Error: could not contact otp_enc_d on port %d##", portNumber);
    sendMessage(error);
  } else {
    //Reads in cipher portion (between @@ and ##)
    size_t length = strstr(buffer, "##")-strstr(buffer, "@@")-2;
    char *cipherText = (char*)malloc(sizeof(char)*(length+1));
    strncpy(cipherText, strstr(buffer, "@@")+2, length);
    cipherText[length] = '\0';
    //Reads in plaintext portion. (Between || and @@)
    length = strstr(buffer, "@@")-strstr(buffer, "||")-2;
    char *plainText = (char*)malloc(sizeof(char)*(length+1));
    strncpy(plainText, strstr(buffer, "||")+2, length);
    plainText[length] = '\0';
    //Encode each character
    int i;
    for(i=0;i<=length;i++){
      encode(&plainText[i], &cipherText[i]);
    }
    //add ## to signal end.
    plainText[length] = '#';
    plainText[length+1] = '#';
    plainText[length+2] = '\0';
    //Return encoded text to client.
    sendMessage(plainText);
  }
}

char * receiveMessage(){    //Receives and returns a message from client (of size 256)
  int charsRead;
  char* buffer = calloc(256, sizeof(char));
  charsRead = recv(establishedConnectionFD, buffer, 255, 0);
  if (charsRead < 0)
    error("ERROR reading from socket");
  return buffer;
}

void sendMessage(char* buffer){   //Sends off a passed in message to client.
  int charsRead = send(establishedConnectionFD, buffer, strlen(buffer), 0); // Send message back
  if (charsRead < 0)
    error("ERROR writing to socket");
}


void encode(char *tee, char* too){  //Encodes message.
  //Translates " " space character to 91
  if(*tee == 32){
    *tee = 91;
  }
  if(*too == 32){
    *too = 91;
  }
  //Reduces character number (might be unnecessary)
  *tee = *tee-65;
  *too = *too-65;
  //Adds key char to plaintext char
  *tee = *tee + *too;
  //Modulo
  *tee = *tee%27;
  //Return to proper character
  *tee = *tee+65;
  *too = *too+65;
  //Translates 91 back to space character " "
  if(*tee == 91){
    *tee = 32;
  }
  if(*too == 91){
    *too = 32;
  }
}
