#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

int socketFD;

void error(const char *msg) { perror(msg); exit(0); } // Error function used for reporting issues
void sendMessage(char*);      //Sends message to server
char * receiveMessage();      //Receives message from server
char * getFile(char*);        //Gets file contents

int main(int argc, char *argv[]){
  srand(time(NULL) + getpid());
  //Variables to be used later on communciation with server
  int portNumber;
  struct sockaddr_in serverAddress, clientAddress;
  struct hostent* serverHostInfo;
  //Buffer to handle plaintext/ciphertext/key
  char buffer[150000];
  char* encryptedText = calloc(75000, sizeof(char));
  char* cipherText = calloc(75000, sizeof(char));


  if (argc < 3) {
    fprintf(stderr,"USAGE: %s hostname port\n", argv[0]); exit(0); } // Check usage & args

    // Set up the server address struct
    memset((char*)&serverAddress, '\0', sizeof(serverAddress)); // Clear out the address struct
    portNumber = atoi(argv[3]); // Get the port number, convert to an integer from a string
    serverAddress.sin_family = AF_INET; // Create a network-capable socket
    serverAddress.sin_port = htons(portNumber); // Store the port number
    serverHostInfo = gethostbyname("localhost"); // Convert the machine name into a special form of address
    if (serverHostInfo == NULL) {
      fprintf(stderr, "CLIENT: ERROR, no such host\n");
      exit(0);
    }
    memcpy((char*)&serverAddress.sin_addr.s_addr, (char*)serverHostInfo->h_addr, serverHostInfo->h_length); // Copy in the address

    //Set up the client address structs
    memset((char *)&clientAddress, '\0', sizeof(clientAddress)); // Clear out the address struct
    portNumber = rand() % 65535;// Get the port number. Randomize to the 30000-65535 range.
    if(portNumber < 20000){
      portNumber = portNumber + 30000;
    }
    clientAddress.sin_family = AF_INET; // Create a network-capable socket
    clientAddress.sin_port = htons(portNumber); // Store the port number
    clientAddress.sin_addr.s_addr = inet_addr("127.0.0.1"); // Any address is allowed for connection to this process

    // Set up the socket
    socketFD = socket(AF_INET, SOCK_STREAM, 0); // Create the socket
    if (socketFD < 0) {
      error("CLIENT: ERROR opening socket");// Connect to server
      return 2;
    }
    if (bind(socketFD, (struct sockaddr *)&clientAddress, sizeof(clientAddress)) < 0){ // Connect socket to port
      error("ERROR on binding");
      return 2;
    }
    if (connect(socketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){ // Connect socket to address
      error("CLIENT: ERROR connecting");
      return 2;
    }

    // Send message to servers
    encryptedText = getFile(argv[1]);     //Reads in from filename
    cipherText = getFile(argv[2]);     //Reads in from filename
    if(strlen(encryptedText) > strlen(cipherText)){
      error("ERROR: Cipher must be at least as long as plaintext\n");
      return 1;
    }
    memset(buffer, '\0', sizeof(buffer));
    int i;
    buffer[0] = 'd';    //Communicate that we are a decoding terminal
    buffer[strlen(buffer)] = '|';
    buffer[strlen(buffer)] = '|';
    //Place full plaintext between the characters "||" and "@@"
    for(i = 0; i < strlen(encryptedText); i++){
      buffer[strlen(buffer)] = encryptedText[i];
      if(encryptedText[i] != 32 && (encryptedText[i] < 65 || encryptedText[i] > 90)){
        error("ERROR: Cipher contains illegal characters\n");
        return 1;
      }
    }
    buffer[strlen(buffer)] = '@';
    buffer[strlen(buffer)] = '@';
    //Place full plaintext between the characters "@@" and "##"
    for(i = 0; i < strlen(cipherText); i++){
      buffer[strlen(buffer)] = cipherText[i];
      if(cipherText[i] != 32 && (cipherText[i] < 65 || cipherText[i] > 90)){
        error("ERROR: Key contains illegal characters\n");
        return 1;
      }
    }
    buffer[strlen(buffer)] = '#';
    buffer[strlen(buffer)] = '#';

    sendMessage(buffer);    //Send buffer to the server

    char* readBuffer = calloc(256, sizeof(char));   //This will be used when we read in the response from the server 256 chars at a time
    memset(buffer, '\0', sizeof(buffer)); // Clear the buffer

    while (strstr(buffer, "##") == NULL) {// As long as we haven't found the terminal...
      memset(readBuffer, '\0', sizeof(readBuffer)); // Clear the buffer
      readBuffer = receiveMessage(); // Get the next chunk
      strcat(buffer, readBuffer); // Add that chunk to what we have so far
    }
    buffer[strlen(buffer)-2] = '\0';//TODO Consider using strstr
    if(buffer[0] == '!'){   //This means the server returned with an error. We read send it to stderr and return 1.
      error(buffer);
      return 1;
    }
    printf("%s\n", buffer); //Read out response from server.

    close(socketFD); // Close the socket
    return 0;
  }

void sendMessage(char* buffer){   //Sends passed in message to the server
  int charsWritten = send(socketFD, buffer, strlen(buffer), 0); // Write to the server
  if (charsWritten < 0)
    error("CLIENT: ERROR writing to socket");
  if (charsWritten < strlen(buffer))
    printf("CLIENT: WARNING: Not all data written to socket!\n");// Get return message from server
}

char * receiveMessage(){    //Receives and returns a message from client (of size 256)
  char* buffer = calloc(256, sizeof(char));
  int charsRead = recv(socketFD, buffer, 255, 0); // Read data from the socket, leaving \0 at end
  if (charsRead < 0)
    error("CLIENT: ERROR reading from socket");
  return buffer;
}

char * getFile(char * filename) {     //Reads in file from filename
  //Open file
  FILE * f = fopen (filename, "rb");
  //Get size
  fseek(f, 0L, SEEK_END);
  int size = ftell(f);
  //Rewind
  rewind(f);
  char* fileInfo = calloc(size, sizeof(char));
  //Read in info to char
  fgets(fileInfo, size, f);
  return fileInfo;
}
