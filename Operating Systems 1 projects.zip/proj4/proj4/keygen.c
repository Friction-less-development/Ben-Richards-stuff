#include <stdio.h>
#include <stdlib.h>


int main(int argc, char **argv)
{
  srand ( time(NULL) );
  int length = atoi(argv[1]);   //Gets length of key to make.
  char* randomKey = calloc(length+1, sizeof(char));

  int i;
  for(i=0;i<length;i++){    //Populate with random capital letter or space.
    randomKey[i] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ "[random () % 27];
  }
  randomKey[length] = '\0'; //Add eof character

  printf(randomKey);  fflush(stdout); //Print it out.
  printf("\n");  fflush(stdout);
  return 0;
}
