I just use gcc, it's a c script.

1. To compile
gcc -o smallsh smallsh.c

2. To run
smallsh

3. To test
chmod +x ./p3testscript
p3testscript > mytestresults 2>&1