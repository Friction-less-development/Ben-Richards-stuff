#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>

int exitStatus = 0; //exitstatus of the last run command
char* outFile;      //File to pipe out to of last run command
char* inFile;       //File to pipe in from of last run command
int targetFD = NULL;  //Used to pipe out
int intargetFD = NULL;  //Used to pipe in
int backgroundProcess = -1;   //If last run command is a background process this will be "1"
int *backgroundPids;          //List of pids of running background processes
int backgroundPidNum = 0;     //A counter of how many background pids there are.
int canBackground = 1;        //A boolean that is set by ctrl-z to enable/disable background processes
pid_t processId;              //child id of last run process

void smallshLoop();           //Loops that takes input commands
char** getArgs(char*);        //Takes the user input and turns it into an array of args
char* breakOff(char**);       //Breaks off the first word from an input and removes it from the string passed in. Passing in "The fox is red" will return "The" and the original string will be changed to "fox is red"
void printArgs(char**);//for debugging
void redirectPipeOut(char *); //Redirects stdout for child process
void redirectPipeIn(char *);  //Redirects stdin for child process
void signalSetup();           //Overwrites signal handling
void handleSigint(int);       //New function for handling Sigint
void handleSigtstp(int);      //New function for handling sigtstp
void handleSigchild(int);     //New function for handling sigchild
void removePid(int);          //Removes pid from backgroundPids variable
void addPid(int);             //Adds pid to backgroundPids variable
void printPid();  //for debugging
int isBackgroundPid(int);     //If passed in int is in the backgroundPids variable, returns true
int isComment(char**);        //If input is a comment (I.e it's first char is "#") return true
int isEmpty(char **);         //If passed in string is empty, return true
char* convertPid(char[], int);    //changes "$$" in the passed in string to process id.



int main(/*int argc, char **argv*/)
{
  signalSetup();

  // Run command loop.
  smallshLoop();

  return 1337;
}


void signalSetup(){
  signal(SIGCHLD, handleSigchild);
  signal(SIGINT, handleSigint);
  signal(SIGTSTP, handleSigtstp);
}

void handleSigchild (int signal){
  pid_t pid;
  int status;
  //All terminated children that are in our list of background pids
  while ((pid = waitpid(-1, &status, WNOHANG)) != -1 && isBackgroundPid(pid))
  {
    //Print message to the user
    printf("background pid %d is done: ", pid); fflush(stdout);
    //If child was terminated by a signal, print information on it.
    if(WTERMSIG(status)){
      printf("terminated by signal %d\n", WTERMSIG(status)); fflush(stdout);
    } else {
    //Else print exit value.
      printf("exit value %d\n", WEXITSTATUS(status)); fflush(stdout);
    }
    //Kill process and remove it from out background process list.
    kill(pid, SIGKILL);
    removePid(pid);
  }
}

void handleSigtstp(int signal){ //All this does is set a boolean that enables/disables being able to set up background processes
  if(canBackground){
    printf("Entering foreground-only mode (& is now ignored)\n"); fflush(stdout);
    canBackground = 0;
  } else {
    printf("Exiting foreground-only mode\n"); fflush(stdout);
    canBackground = 1;
  }
}

void handleSigint(int signal) {
  //Kill background processes one by one.
  if(backgroundPidNum){
    do {
      if(kill(backgroundPids[backgroundPidNum-1], SIGINT) != -1){
        removePid(backgroundPids[backgroundPidNum-1]);
        printf("terminated by signal 2\n"); fflush(stdout);
      } else {
        printf("Error terminating %d\n", backgroundPids[backgroundPidNum-1]); fflush(stdout);//Throw errno?
      }
    } while(backgroundPidNum);
  }
  //Then kill foreground process
  int status;
  if(waitpid(processId, &status, WNOHANG) != -1){
    if(kill(processId, SIGINT) == -1){
      printf("Error terminating %d\n", processId); fflush(stdout);//Throw errno?
    } else {
      printf("terminated by signal 2\n"); fflush(stdout);
    }
  }
}

void smallshLoop() //Reads in input and executes it.
{
  int loopStatus = 1; //Means loop is running. gets set to zero when user enters "exit"

  do {
    printf(": "); fflush(stdout);
    //Reads in user input
    char *input = NULL;
    ssize_t bufsize = 0;
    getline(&input, &bufsize, stdin);
    //Translates input to arguments, returned in an array
    char **args;
    args = getArgs(input);

    if (args[0] && strcmp(args[0],"")!=0){  //If there are args
      if(strcmp(args[0],"exit") == 0){      //If first command is "exit". Then exit loop.
        loopStatus = 0;
      } else if(strcmp(args[0],"status") == 0){     //If first command is "status". Print last exitStatus
        printf("exit value %d\n", exitStatus); fflush(stdout);
      } else if(strcmp(args[0],"cd") == 0){         //If first command is cd, utilize chdir.
        char *gdir;
        if(args[1] && strcmp(args[1],"")!=0){       //If additional arguments.
          char buf[1000];
          gdir = getcwd(buf, sizeof(buf));
          gdir = strcat(gdir, "/");
          gdir = strcat(gdir, args[1]);
        } else {                                    //Else use environment variable HOME
          gdir = getenv("HOME");
          exitStatus = 1;
        }
        if(chdir(gdir) == -1){                      //chdir and print results
          exitStatus = 1;
        } else {
          printf(gdir);
          printf("\n"); fflush(stdout);
          exitStatus = 0;
        }
      } else {                                //If first var is unknown then treat it as a process.
        startProcess(args);
      }
      backgroundProcess = -1;//At end of loop we reset backgroundProcess variable
    }
  } while (loopStatus);
}

char** getArgs(char* input){ //512 arguments
  char** arg = malloc(sizeof(char*)*512);
  if(isComment(&input) == 1){           //If the input is a comment, we return nothing.
    return arg;
  }
  int i = 0;
  do {      //Loop through arguments in input
    char* firstArg = malloc(sizeof(char)*1536);//2048 - 512
    firstArg = breakOff(&input);    //The current arg for this loop run.
    if(strcmp(firstArg, ">") == 0){   //Handle pipingout
      char * secondArg = breakOff(&input);
      outFile = malloc(sizeof(secondArg));
      strcpy(outFile, secondArg);
      i = i+2;
    } else if(strcmp(firstArg, "<") == 0){   //Handle pipingin
      char * secondArg = breakOff(&input);
      inFile = malloc(sizeof(secondArg));
      strcpy(inFile, secondArg);
      i = i+2;
    } else if (strcmp(firstArg, "&") == 0) {  //Handle ampersand. Make sure it's the final argument before setting backgroundProcess to one.
      if(canBackground){
        if(isEmpty(&input) == 1){
          backgroundProcess = 1;
        } else {                              //Case where it is NOT the last argument. We treat it as regular arg then.
          arg[i] = malloc(sizeof(firstArg));
          strcpy(arg[i], firstArg);
          i++;
        }
      }
    } else {                                  //Regular arg. We add it to the array.
      arg[i] = malloc(sizeof(firstArg));
      strcpy(arg[i], firstArg);
      i++;
    }
  } while (strcmp(input,"") != 0);

  return arg;
}

int isComment(char** input){      //Checks if input is a comment. Basically loops until it reaches the first char or EOF. If first char is "#" return true. Else false
  int returnValue = 0;
  char* quotePtr = *input;
  while(!returnValue) {
    if(*quotePtr == ' '){
      quotePtr++;
    } else if(*quotePtr == '#'){
      return 1;
    } else if (*quotePtr == '\0' || *quotePtr == '\n'){
      return -1;
    } else {
      returnValue = -1;
    }
  }
  return returnValue;
}

int isEmpty(char ** input){         //Checks if input is empty. Loops through input until EOF. If finds a char that is not an empty space returns false. Else returns true.
  char* quotePtr = *input;
  int returnValue = 0;
  while(!returnValue) {
    if(*quotePtr == ' '){
      quotePtr++;
    } else if (*quotePtr == '\0' || *quotePtr == '\n'){
      returnValue = 1;
    } else {
      returnValue = -1;
    }
  }
  return returnValue;
}

char* breakOff(char** input){     //Returns first word in a sentence and erases that word from the inputted string
  char* startingValue = *input;
  char* quotePtr;
  int hasPid = 0;
  for (quotePtr = *input; *quotePtr != '\0'; quotePtr++){
    if(*quotePtr == ' ' || *quotePtr == '\n'){
      break;
    }
    if(*quotePtr == '$' && *(quotePtr+1) == '$'){   //Uneeded? We loop through to find this again in convertPid. This is only to calculate memory allocation.
      hasPid++;
    }
  }

  *input = quotePtr+1;  //Breaks off from inputl

  char subString[quotePtr-startingValue+1];
  memcpy( subString, &startingValue[0], (quotePtr-startingValue) );
  subString[(quotePtr-startingValue)] = '\0';
  char* returnValue = malloc(sizeof(char)*(quotePtr-startingValue+1));
  returnValue = subString;
  if(hasPid){
    returnValue = convertPid(returnValue, hasPid);      //Convert any instance of "$$" in the string to pid.
  }
  return returnValue;
}

char* convertPid(char string[], int numTimes /*for memory allocation*/){    //Convert any instance of $$ in the string to pid.
  int value = getpid();
  int i;
  char* returnValue = malloc(sizeof(string)+sizeof(value)*numTimes);
  for (i = 0; i < strlen(string); i++){       //Loops through string/
    if(string[i] == '$' && string[i+1] == '$'){   //If we run into a case of "$$"
      returnValue[i] = '%';                 //Change "$$" to "%d" in the new string
      returnValue[i+1] = 'd';
      i++;
    } else {
      returnValue[i] = string[i];         //Else copy normal contents.
    }
  }
  //Use snprintf to change "%d" to pid
  char* buffer = malloc(sizeof(returnValue));
  snprintf(buffer, sizeof(buffer)*2, returnValue, value); //NOTE this is practical but not 100% safe
  return buffer;
}

int startProcess(char **args)   //Starts child processes
{
  pid_t waitOn;   //For waitpid
  int status;
  processId = fork();
  if (processId < 0) {        //Case fork fails
    // Add in error
    printf("error1"); fflush(stdout);//
    exitStatus = 1;
  } else if (processId == 0) {  // Case child
    //Handle piping
    redirectPipeOut(outFile);
    redirectPipeIn(inFile);
    //Execute process
    int state = execvp(args[0], args);
    if (state == -1) {
      //Add in error
      printf(args[0]);
      printf(": no such file or directory\n");fflush(stdout);
    }
    //Close pipes.
    if(targetFD && targetFD != -1){
      close(targetFD);
    }
    if (intargetFD && intargetFD != -1){
      close(intargetFD);
    }
    exit(EXIT_FAILURE);
  } else {// Case parent
    do {
      if(backgroundProcess == 1){   //If this is a BACKGROUND process....
        //We use NOHANG to execute the child
        waitOn = waitpid(processId, &status, WNOHANG);
        //We spit out the pid of the background process
        printf("background pid is %d\n", processId); fflush(stdout);
        //We add the pid to an array for us to keep watch on
        addPid(processId);
      } else {
        //We wait for the child to finish processing
        waitOn = waitpid(processId, &status, WUNTRACED);
      }
    } while (!WIFEXITED(status) && !WIFSIGNALED(status));
    //Here we reset variables related to piping.
    targetFD = -1;
    intargetFD = -1;
    inFile = malloc(sizeof(""));
    outFile = malloc(sizeof(""));
    strcpy(inFile, "");
    strcpy(outFile, "");
    //Exitstatus of last child.
    exitStatus = WEXITSTATUS(status);
  }
  return 1;
}

void printArgs(char **args){    //For debugging
  printf("\n:\n");
  int i;
  for(i=0;i<512;i++){
    if(args[i] != NULL && strcmp(args[i],"") != 0){
      printf(args[i]);
      printf("\n");
    } else{
      printf("END\n");
      i=512;
    }
  }
  printf(":\n"); fflush(stdout);
}

void redirectPipeOut(char *outFilename){
  if(outFilename != NULL && strcmp(outFilename, "") != 0){
    targetFD = open(outFilename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (targetFD == -1)
    {
      perror(outFilename); exit(1);
    }
    dup2(targetFD, 1);
  }
}

void redirectPipeIn(char *inFilename){
  if(inFilename != NULL && strcmp(inFilename, "") != 0){
    intargetFD = open(inFilename, O_RDONLY, 0644);
    if (intargetFD == -1)
    {
      perror(inFilename); exit(1);
    }
    dup2(intargetFD, 0);
  }
}

void addPid(int pid){   //Add background pid to an array
  if(backgroundPids){
    backgroundPidNum++;
    backgroundPids = realloc(backgroundPids, backgroundPidNum * sizeof(int));
  } else {
    backgroundPidNum++;
    backgroundPids = calloc(backgroundPidNum, sizeof (int));
  }
  backgroundPids[backgroundPidNum-1] = pid;
}

void removePid(int pid){  //Remove background pid from an array
  int i;
  for(i=0;i<backgroundPidNum;i++){
    if(backgroundPids[i] == pid){
      backgroundPids[i] = backgroundPids[backgroundPidNum-1];
      break;
    }
  }
  backgroundPidNum--;
  backgroundPids = realloc(backgroundPids, backgroundPidNum * sizeof(int));
}


int isBackgroundPid(int pid){   //Checks if passed in int is in backgroundPid array
  int i;
  for(i=0;i<backgroundPidNum;i++){
    if(backgroundPids[i] == pid){
      return 1;
    }
  }
  return 0;
}

void printPid(){    //for debugging
  printf("\n");
  int i;
  for(i=0;i<backgroundPidNum;i++){
    printf("%d\n", backgroundPids[i]);
  }
  fflush(stdout);
}
