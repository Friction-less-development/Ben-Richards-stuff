#include <iostream>
#include "Board.h"
//#include "Board1.dat"
using namespace std;

void lazyProgrammer();

int main()
{
    int choice;
    int choice2;
    int choice3;
    char choice4;
    int turnCount = 0;
    Board theBoard;
    const char* Board1 = "board1.dat";
    theBoard.readBoard(Board1);

    cout << "**********************************************" << endl;
    cout << "Welcome to Blackout. Make everything 0 by flipping." << endl;
    cout << "It's important to note the numbering." << endl;
    cout << "12345678" << endl;
    cout << "2\n3\n4\n5\n6\n7\n8" << endl;
    cout << "Good Luck\n*********************************************" << endl << endl;

while(true){


    std::cout << theBoard.actuallyReadBoard() << endl;
    cout << "1. Flip Row, \n2. Flip Collumn. \n3. Turn cell on.\n4. Turn cell off.\n5. Shift Left or Right\n6. Shift up or down\n7. Quit\n98. SUPAH MEGA BOARD TURN OVER (For testing: Turns everything to 0)\n" << endl;
    cin>>choice;
    if(choice == 1)
    {
        cout << "Which row do you want to flip: " <<endl;
        cin >> choice2;
        if(choice2 >8 || choice2 <0)
            lazyProgrammer();
        else
            turnCount++;
        theBoard.switchRow(choice2);
    }
    else if(choice == 2)
    {
        cout << "Which Collumn do you want to flip: " <<endl;
        cin >> choice2;
        if(choice2 >8 || choice2 <0)
            lazyProgrammer();
        else
            turnCount++;
        theBoard.switchCollumn(choice2);
    }
    else if(choice == 3 || choice == 4)
    {
        cout << "Which row do you want to flip: " <<endl;
        cin >> choice2;
        if(choice2 >8 || choice2 <0)
            lazyProgrammer();
        else
            turnCount++;
        cout << "Which Collumn do you want to flip: " <<endl;
        cin >> choice3;
        if(choice3 >8 || choice3 <0)
            lazyProgrammer();
        else
            turnCount++;
        turnCount--;
        theBoard.turnCellOver(choice2, choice3);
    }
    else if(choice == 5)
    {
        cout << "Which row do you want to shift? " <<endl;
        cin >> choice2;
        if(choice2 >8 || choice2 <0)
            lazyProgrammer();
        else
            turnCount++;
        cout << "Which Direction do you want to shift? L|R" <<endl;
        cin >> choice4;

        theBoard.shiftLeftOrRight(choice2, choice4);
    }
    else if(choice == 6)
    {
        cout << "Which Column do you want to shift? " <<endl;
        cin >> choice2;
        if(choice2 >8 || choice2 <0)
            lazyProgrammer();
        else
            turnCount++;
        cout << "Which Direction do you want to shift? U|D" <<endl;
        cin >> choice4;

        theBoard.shiftUpOrDown(choice2, choice4);
    }
    else if(choice == 7)
    {
        break;
    }
    else if(choice == 98)
    {
        theBoard.supahMegaBoardTurnover();
        turnCount++;
    }
    else
    {
        cout << "Please choose a number between 0 and 5" << endl;
    }
    if(theBoard.CheckWinning())
    {
        cout<< "YOU WIN HALLELUJAH BING BANG\nTurn Count: " << turnCount << "\nbreak;" << endl;
        break;
    }
}
/*
    std::cout << "original board:\n" << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(1,1);
    std::cout << "turning diagonal line to 1\n " << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(2,2);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(3,3);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(4,4);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(5,5);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(6,6);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(7,7);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.turnCellOn(8,8);
    std::cout << theBoard.actuallyReadBoard() << endl;
    cout << "Turning diagonal line to 0\n" << endl;
    for(int i = 1; i < 9; i++)
    {
    theBoard.turnCellOff(i,i);
    std::cout << theBoard.actuallyReadBoard() << endl;
    }
    cout<< "Switch row 2" <<endl;
    theBoard.switchRow(2);
    std::cout << theBoard.actuallyReadBoard() << "Switch collumn 1,2,3" <<endl;
    theBoard.switchCollumn(1);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.switchCollumn(2);
    std::cout << theBoard.actuallyReadBoard() << endl;
    theBoard.switchCollumn(3);
    std::cout << theBoard.actuallyReadBoard() << endl;

//    theBoard.shiftLeftOrRight(2, 'L');
  //  std::cout << theBoard.actuallyReadBoard() << endl;
    //theBoard.shiftUpOrDown(2, 'D');
    //std::cout << theBoard.actuallyReadBoard();


*/

    return 0;
}


void lazyProgrammer()
{
    cout << "Hey. Your input should be between 0 and 8. Come on, work with me here (Your turn count will nicely be decremented now move along)" << endl;
}
