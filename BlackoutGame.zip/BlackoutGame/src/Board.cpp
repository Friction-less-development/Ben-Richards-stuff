#include "Board.h"
#include <iostream>
#include <fstream>

using namespace std;

Board::Board()
{
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        board[i] = 0;
    }
}

void Board::readBoard(const char *filename)
{
    ifstream input;
    char word[9];
    input.open(filename);
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        input >> word;
        for (int j = 0; j < 8; j++)
        {
            board[i] |= word[j] & 0x01;
            if (j != 7)
            {
                board[i] <<= 1;
            }
        }
    }
    input.close();

 /*   const char* Board2 = "board2.dat";
    ifstream input2;
    char word2[9];
    input2.open(Board2);
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        input2 >> word2;
        for (int j = 0; j < 8; j++)
        {
            boardValues[i] |= word2[j] & 0x01;
            if (j != 7)
            {
                boardValues[i] <<= 1;
            }
        }
    }
    input2.close();

    ifstream input3;
    char word3[9];
    input3.open("board3.dat");
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        input3 >> word3;
        for (int j = 0; j < 8; j++)
        {
            boardValues[i] |= word3[j] & 0x01;
            if (j != 7)
            {
                boardEmpty[i] <<= 1;
            }
        }
    }
    input3.close();

    ifstream input4;
    char word4[9];
    input4.open("board4.dat");
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        input4 >> word4;
        for (int j = 0; j < 8; j++)
        {
            boardValuesNeg[i] |= word4[j] & 0x01;
            if (j != 7)
            {
                boardValuesNeg[i] <<= 1;
            }
        }
    }
    input4.close();*/

}

std::string Board::actuallyReadBoard()
{
    std::string ss;
    for(int i = 0; i < 8; i++)
    {
        for (int j = 7; j >= 0; j--)
        {

            ss += ((board[i] >> j) & 1 ? '1' : '0');        //We read the board digits into a string.
        }
        ss += "\n";
    }
    return ss;
}

void Board::shiftLeftOrRight(int row, char direction)
{
    int leftValue;
    int rightValue;
    if(board[row-1] & 0x01<<(7))
        leftValue = 1;
    else
        leftValue = 0;
    if(board[row-1] & 0x01)             //First we grab the left and rightmost values of a row.
        rightValue = 1;
    else
        rightValue = 0;

    if(direction == 'L' || direction == 'l')        //Then depending on whether we are shifting L or R. We shift the rows over and providing the oppisote sides value was a 1, we change the new digit to a 1.
    {
        board[row-1] <<= 1;
        if(leftValue == 1)
            board[row-1] ^= 0x01;
    }
    if(direction == 'R' || direction == 'r')
    {
        board[row-1] >>= 1;
        if(rightValue == 1)
            board[row-1] ^= 0x01<<(7);
    }
}

void Board::shiftUpOrDown(int column, char direction)
{
    column = 8-column;              //This lines it up with our numbering system
    int valuesToShift[8];           //This is an array of values that are in the Column
    for(int i = 0; i < 8; i++)
    {
        valuesToShift[i] = board[i] & 0x01<<(column);           //this sets the array to the values in the given column
    }

    if(direction == 'U' || direction == 'u')                    //this sets the column to the values in the array created above with an offset of one
    {
        for(int i = 0; i < 8; i++)
        {
            if(i == 7)
            {
                if(valuesToShift[0] != (board[i]& 0x01<<(column)))
                {
                    board[i] ^= 0x01<<(column);
                }
            }
            else
            {
                if(valuesToShift[i+1] != (board[i]& 0x01<<(column)))
                {
                    board[i] ^= 0x01<<(column);
                }
            }
        }
    }

    if(direction == 'd' || direction == 'D')
    {
        for(int i = 7; i >= 0; i--)
        {
            if(i == 0)
            {
                if(valuesToShift[7] != (board[i]& 0x01<<(column)))
                {

                    board[i] ^= 0x01<<(column);
                }
            }
            else
            {
                if(valuesToShift[i-1] != (board[i]& 0x01<<(column)))
                {
                    board[i] ^= 0x01<<(column);
                }
            }
        }
    }


}

void Board::switchRow(int row)
{
//    string ss;
    row--;
    for(int i = 0; i < 8; i++)
    {
        board[row] ^= 0x01<<(i);
    }

//The following is..some crazy stuff I made back when I didn't quite know what I was doing. Yeah.

    /*
    unsigned char newRow[8];
    for(int i = 7; i >= 0; i--)
    {
        newRow[i] = ((board[row] >> i) & 1 ? '0' : '1');
//       ss += ((board[row] >> i) & 1 ? '0' : '1');
    }
//    std::cout << ss << endl;

    unsigned char newNewRow[8];
    for(int i = 0, j = 7; i < 8; i++, j--)  //I really don't know. I can't get newRow to reverse in the next loop so I did this.
    {
        newNewRow[i] = newRow[j];
    }

    for (int j = 0; j < 8; j++)
    {
        board[row] |= newNewRow[j] & 0x01;
        if (j != 7)
        {
            board[row] <<= 1;
        }
    }*/
}

void Board::switchCollumn(int Collumn)
{
    Collumn = 8-Collumn;        //Sets column to our numbering system
    unsigned char newChar[8];

    for (int j = 7; j >= 0; j--)
    {
        board[j] ^= 0x01<<(Collumn);
    }
}

void Board::turnCellOver(int row, int column)
{
    board[row-1] ^= 0x01<<(8-column);
}

void Board::supahMegaBoardTurnover()
{
    for(int i = 0; i < 8; i++)
    {
        board[i] = 0;
    }
}


bool Board::CheckWinning()
{
    int bigCashWinnings = 0;
    for(int i = 0; i < 8; i++)
    {
        if(board[i] == 0)
            bigCashWinnings++;
    }
    if(bigCashWinnings == 8)
        return true;
    else
        return false;
}

