#ifndef BOARD_H
#define BOARD_H

#include <string>

using namespace std;

class Board
{
    public:
        Board();
        void readBoard(const char *filename);       //Reads the board into the program
        std::string actuallyReadBoard();        //Actually reads the board to the screen

        void shiftLeftOrRight(int row, char direction);     //shifts rows left or right
        void shiftUpOrDown(int collumn, char direction);    //shifts collumns up or down

        void switchRow(int row);        //switches the values in a row
        void switchCollumn(int row);    //switches the values in a collumn

        void turnCellOver(int row, int column);     //switches the value in a specific cell

        void supahMegaBoardTurnover();              //Turns everything in 0, ending the game.

        bool CheckWinning();                        //Checks to see if the game is won.

        static const int BOARD_SIZE = 8;
        const unsigned MASK = 0x01;
    protected:
    private:
        unsigned char board[BOARD_SIZE];
//        unsigned char boardValues[BOARD_SIZE];
  //      unsigned char boardValuesNeg[BOARD_SIZE];
    //    unsigned char boardEmpty[BOARD_SIZE];
};

#endif // BOARD_H
