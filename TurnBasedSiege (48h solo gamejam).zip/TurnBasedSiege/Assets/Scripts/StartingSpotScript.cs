﻿using UnityEngine;
using System.Collections;

public class StartingSpotScript : MonoBehaviour {
    private StateMachine stateMachine;
    

	// Use this for initialization
	void Start () {
        TileScript ts = GetComponentInParent<TileScript>();
        ts.setIsStartingSpot(true);
        GameObject gameController = GameObject.FindWithTag("GameController");
        stateMachine = gameController.GetComponent<StateMachine>();
	}
	
	// Update is called once per frame
	void Update () {
        if(stateMachine.getGameState() == 4)
        {
            if(stateMachine.getPlayerTurn() == (GetComponentInParent<TileScript>().playerOwnedBy*-1))
            {
                gameObject.GetComponent<SpriteRenderer>().enabled = true;
            }
        }
        else
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
      
	
	}
}
