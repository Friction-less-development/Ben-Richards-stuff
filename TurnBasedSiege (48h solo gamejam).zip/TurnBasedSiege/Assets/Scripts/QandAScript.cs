﻿using UnityEngine;
using System.Collections;

public class QandAScript : MonoBehaviour {

    private StateMachine stateMachine;
    private string player1Question = "";
    private string player2Question = "";
    private string player1Answer = "";
    private string player2Answer = "";

    private string player1QuestionSwitch = "";
    private string player2QuestionSwitch = "";
    private string player1AnswerSwitch = "";
    private string player2AnswerSwitch = "";

    private bool player1QuestionResetSwitch = false;
    private bool player2QuestionResetSwitch = false;
    private bool player1AnswerResetSwitch = false;
    private bool player2AnswerResetSwitch = false;
    private bool debugSwitch = false;

    public void setPlayer1Question(string set)
    {
        player1Question = set;
    }
    public void setPlayer2Question(string set)
    {
        player2Question = set;
    }
    public void setPlayer1Answer(string set)
    {
        player1Answer = set;
    }
    public void setPlayer2Answer(string set)
    {
        player2Answer = set;
    }
    public string getPlayer1Question()
    {
        return player1Question;
    }
    public string getPlayer2Question()
    {
        return player2Question;
    }
    public string getPlayer1Answer()
    {
        return player1Answer;
    }
    public string getPlayer2Answer()
    {
        return player2Answer;
    }
    private void wowPlayer1Question()
    {
        if(player1QuestionSwitch != player1Question)
        {
            stateMachine.setGameState(12);
            player1QuestionSwitch = player1Question;
            player1QuestionResetSwitch = true;
        }
    }
    private void wowPlayer2Question()
    {
        if (player2QuestionSwitch != player2Question)
        {
            stateMachine.setGameState(16);
            player2QuestionSwitch = player2Question;
            player2QuestionResetSwitch = true;
        }
    }
    private void wowPlayer1Answer()
    {
        if (player1AnswerSwitch != player1Answer)
        {
            stateMachine.setGameState(18);
            player1AnswerSwitch = player1Answer;
            player1AnswerResetSwitch = true;
        }
    }
    private void wowPlayer2Answer()
    {
        if (player2AnswerSwitch != player2Answer)
        {
            stateMachine.setGameState(14);
            player2AnswerSwitch = player2Answer;
            player2AnswerResetSwitch = true;
        }
    }
    public void resetPlayer2Answer()
    {
        if(player2AnswerResetSwitch == true)
        {
            player2Answer = "";
            player2AnswerSwitch = "";
            player2AnswerResetSwitch = false;
        }
    }
    public void resetPlayer1Answer()
    {
        if (player1AnswerResetSwitch == true)
        {
            player1Answer = "";
            player1AnswerSwitch = "";
            player1AnswerResetSwitch = false;
        }
    }
    public void resetPlayer1Question()
    {
        if (player1QuestionResetSwitch == true)
        {
            player1Question = "";
            player1QuestionSwitch = "";
            player1QuestionResetSwitch = false;
        }
    }
    public void resetPlayer2Question()
    {
        if (player2QuestionResetSwitch == true)
        {
            player2Question = "";
            player2QuestionSwitch = "";
            player2QuestionResetSwitch = false;
        }
    }

	// Use this for initialization
	void Start () {
        stateMachine = gameObject.GetComponent<StateMachine>();
	}
	
	// Update is called once per frame
	void Update () {
        wowPlayer1Question();
        wowPlayer2Question();
        wowPlayer1Answer();
        wowPlayer2Answer();
	
	}
}
