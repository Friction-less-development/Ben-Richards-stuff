﻿using UnityEngine;
using System.Collections;

public class SpecialTileScript : MonoBehaviour {
    private StateMachine stateMachine;
    private TileScript parentTileScript;
    private bool found;

	// Use this for initialization
	void Start () {
        found = false;
        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
        parentTileScript = GetComponentInParent<TileScript>();
	}
	
	// Update is called once per frame
	void Update () {
        if (stateMachine.getGameState() >= 10 && stateMachine.getGameState() <=18)
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
        else
        {
            if (found != true)
            {
                if (parentTileScript.playerOwnedBy != stateMachine.getPlayerTurn())
                    gameObject.GetComponent<SpriteRenderer>().enabled = false;
                else
                    gameObject.GetComponent<SpriteRenderer>().enabled = true;
            }
            else
                gameObject.GetComponent<SpriteRenderer>().enabled = true;
        }
       

	}
    public void Found()
    {
      //Debug.Log("Well I'm receiving a found request");
        found = true;
        gameObject.GetComponent<SpriteRenderer>().enabled = true;
    }
}
