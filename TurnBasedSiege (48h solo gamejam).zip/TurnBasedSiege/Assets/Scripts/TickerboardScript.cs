﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TickerboardScript : MonoBehaviour {
    public AudioClip fruitlessSearch;
    public AudioClip fruitfulSearch;
    public AudioClip trapPlace;
    public AudioClip trapped;
    public AudioSource mySource;
    Text theText;

	// Use this for initialization
	void Start () {
        theText = GetComponent<Text>();
        mySource = GetComponent<AudioSource>();
	}

    public void choiceMove(int player)
    {
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has chosen: Move \n";
        if (player == -1)
            tempString += "Player 2 has chosen: Move \n";
        tempString += theText.text;
        theText.text = tempString;
    }

    public void choiceTrap(int player)
    {
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has chosen: Trap \n";
        if (player == -1)
            tempString += "Player 2 has chosen: Trap \n";
        tempString += theText.text;
        theText.text = tempString;
    }
    public void choiceQuestion(int player)
    {
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has chosen: Question \n";
        else if (player == -1)
            tempString += "Player 2 has chosen: Question \n";
        tempString += theText.text;
        theText.text = tempString;
    }
    public void trapDeath(int player)
    {
        mySource.PlayOneShot(trapped, 0.7F);
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has run into a trap! \n";
        else if (player == -1)
            tempString += "Player 2 has run into a trap! \n";
        tempString += theText.text;
        theText.text = tempString;
    }

    public void emptyInvestigation(int player)
    {
        mySource.PlayOneShot(fruitlessSearch, 0.7F);
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 searched the tile and found nothing \n";
        else  if (player == -1)
            tempString += "Player 2 searched the tile and found nothing \n";
        tempString += theText.text;
        theText.text = tempString;
    }

    public void fulfillingInvestigation(int player)
    {
        mySource.PlayOneShot(fruitfulSearch, 0.7F);
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has found Player 2's unconventional weapon! \n";
        else if (player == -1)
            tempString += "Player 2 has found Player 1's unconventional weapon! \n";
        tempString += theText.text;
        theText.text = tempString;
    }
    public void fulfillingTrap(int player)
    {
        mySource.PlayOneShot(trapPlace, 0.7F);
        string tempString = "";
        if (player == 1)
            tempString += "Player 1 has laid down a trap \n";
        else if (player == -1)
            tempString += "Player 2 has laid down a trap \n";
        tempString += theText.text;
        theText.text = tempString;
    }
    public void askedQuestion(int player, string question)
    {
        string tempString = "";
        if (player == 1)
        {
            tempString += "Player 1 asked Player 2: ";
            tempString += question;
            tempString += "\n";

        }
        else if (player == -1)
        {
            tempString += "Player 2 asked Player 1: ";
            tempString += question;
            tempString += "\n";
        }
        tempString += theText.text;
        theText.text = tempString;
    }
    public void answeredQuestion(int player, string question)
    {
        string tempString = "";
        if (player == 1)
        {
            tempString += "Player 1 answered Player 2 with: ";
            tempString += question;
            tempString += "\n";

        }
        else if (player == -1)
        {
            tempString += "Player 2 answered Player 1 with: ";
            tempString += question;
            tempString += "\n";
        }
        tempString += theText.text;
        theText.text = tempString;
    }
    public void incorrectGuess(int player, string guess)
    {
        mySource.PlayOneShot(fruitlessSearch, 0.7F);
        string tempString = "";
        if (player == 1)
        {
            tempString += "Player 1 incorrectly guessed: ";
            tempString += guess;
            tempString += "\n";

        }
        else if (player == -1)
        {
            tempString += "Player 2 incorrectly guessed: ";
            tempString += guess;
            tempString += "\n";
        }
        tempString += theText.text;
        theText.text = tempString;
    }
    public void empty()
    {
        theText.text = "";
    }

	
	// Update is called once per frame
	void Update () {

	
	}
}
