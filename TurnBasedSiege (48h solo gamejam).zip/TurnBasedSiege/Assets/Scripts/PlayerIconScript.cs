﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerIconScript : MonoBehaviour {
    private StateMachine stateMachine;
    public Texture player1Icon;
    public Texture player2Icon;

	// Use this for initialization
	void Start () {
        stateMachine = GameObject.FindWithTag("GameController").GetComponent<StateMachine>();
	}
	
	// Update is called once per frame
	void Update () {
        if (stateMachine.getGameState() == 1000 || stateMachine.getGameState() == -1000)
            GetComponent<RawImage>().enabled = false;
        else
        {
            if (stateMachine.getPlayerTurn() == 1)
            {
                GetComponent<RawImage>().texture = player1Icon;
            }
            else if (stateMachine.getPlayerTurn() == -1)
            {
                GetComponent<RawImage>().texture = player2Icon;
            }
        }
	
	}
}
