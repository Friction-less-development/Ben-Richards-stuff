﻿using UnityEngine;
using System.Collections;

public class StateMachine : MonoBehaviour {
    private int PlayerTurn; //true is player 1.
    private int GameState;
    private int gameRows;
    private int gameCollumns;
    private bool weaponPathFound = false;
    private bool confirmation = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void setPlayerTurn(int setValue)//1 is player1 -1 is player2
    {
        PlayerTurn = setValue;
    }

    public int getPlayerTurn()
    {

        return PlayerTurn;
    }

    public void setGameState(int setValue)
    {
        GameState = setValue; 
        //-7 Startscreen
        //-6 Player1password
        //-5 Player1PWconfirmation
        //-4 Player2PW
        //-3 player2PWconfirmation
        //-2 Player1weapon
        //-1 Player1weaponconfirmation
        //0 player2weapon
        //100 player2 weapon confirmation
        //1 is menu choice
        //2 is trap setting
        //3 is ??????
        //4 is choosing a spawn point for token
        //5 is moving token
        //6 is player1 guessing password
        //7 is confirmation for 6
        //8 is player2 guessing password
        //9 is confirmation for 8
        //10 is intermission
        //11 is player1questoin
        //12 is player1questionconfirm
        //13 is player2answer
        //14 is player2answerconfirm
        //15 is player2question
        //16 is player2questionconfirm
        //17 is player1answer
        //18 is player1answerconfirm
        //1000 is PLAYER1WIN
        //-1000 is PLAYER2WIN
    }

    public int getGameState()
    {
        return GameState;
    }

    public void setGameRows(int gr)
    {
        gameRows = gr;
    }
    public int getGameRows()
    {
        return gameRows;
    }
    public void setGameCollumns(int gc)
    {
        gameCollumns = gc;
    }
    public int getGameCollumns()
    {
        return gameCollumns;
    }
    public void setWeaponPathFound( bool set)
    {
        weaponPathFound = set;
    }
    public bool getWeaponPathFound()
    {
        return weaponPathFound;
    }
    public void getConfirmation(bool set)
    {
        confirmation = set;
    }
    public bool setConfirmation()
    {
        return confirmation;
    }
}
