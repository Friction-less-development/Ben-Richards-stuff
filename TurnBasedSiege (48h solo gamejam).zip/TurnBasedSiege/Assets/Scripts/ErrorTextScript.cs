﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ErrorTextScript : MonoBehaviour {
    Text theText;
 //   public int bool = true;

    public void isntYourTile()
    {
        Debug.Log("That isn't your tile");
        theText.text = "That isn't your tile";
    }
    public void pathBlocker()
    {
        Debug.Log("You must leave a path from both of your opponents\nspawn points to your unconventional weapon");
        theText.text = "You must leave a path from both of your opponents\nspawn points to your unconventional weapon";
    }
    public void fullSpace()
    {
        Debug.Log("That space is full");
        theText.text = "That space is full";
    }
    public void oneOrTwo()
    {
        Debug.Log("Please choose 1 or 2 by pressing a number key");
        theText.text = "Please choose 1 or 2 by pressing a number key";
    }
    public void alreadySearched()
    {
        Debug.Log("You already searched that place");
        theText.text = "You already searched that place";
    }
    public void Empty()
    {
        theText.text = "";
    }

	// Use this for initialization
	void Start () {
        theText = GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
       /* if(Input.anyKeyDown && theText.text != "")
            theText.text = "";
       if (lagSwitch)
        {
            theText.text = "";
            lagSwitch = false;
        }
        if (Input.anyKeyDown )
        {
            lagSwitch = true;
        }*/
	
	}

}
