﻿using UnityEngine;
using System.Collections;

public class TileScript : MonoBehaviour {
    public int rowNumber;
    public int collumnNumber;
    public Transform trapObject;
    public Transform weaponObject;
    public Sprite checkedTile;

    private StateMachine stateMachine;
    private TickerboardScript tickerBoard;
    private ErrorTextScript errorText;
    private TileManager tileManager;
    private GameController gcScript;
    public int playerOwnedBy;
    public bool isChecked = false;
    private bool hasWeapon = false;
    private bool isStartingSpot = false;
    private bool isPlayerChecked = false;
    private bool trapped = false;
   


	// Use this for initialization
	void Start () {
        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
        tileManager = legameObject.GetComponent<TileManager>();
        gcScript = legameObject.GetComponent<GameController>();
        tickerBoard = GameObject.FindWithTag("Tickerboard").GetComponent<TickerboardScript>();
        errorText = GameObject.FindWithTag("ErrorText").GetComponent<ErrorTextScript>();
	
	}
	
	// Update is called once per frame
	void Update () {
    
	}
    public void setHasWeapon(bool set)
    {
        hasWeapon = set;
    }
    public bool getHasWeapon()
    {
        return hasWeapon;
    }
    public void setIsStartingSpot(bool set)
    {
        isStartingSpot = set;
    }
    public bool getIsStartingSpot()
    {
        return isStartingSpot;
    }
    public bool getIsTrapped()
    {
        return trapped;
    }
    public void setPlayerOwnedBy(int set)
    {
        playerOwnedBy = set;
    }

    public int getPlayerOwnedBy()
    {
        return playerOwnedBy;
    }
    public void setFoundInChild()
    {
        if(trapped == true)
        {
            foreach (Transform child in transform) 
            {
                if(child.tag == "Trap")
                {
                    child.gameObject.GetComponent<SpecialTileScript>().Found();
                }
            }
        }
        else if (hasWeapon == true)
        {
            foreach (Transform child in transform)
            {
                if (child.tag == "Unconventional Weapon")
                {
                  //  Debug.Log("Well I'm sending a found request to the weapon");
                    child.gameObject.GetComponent<SpecialTileScript>().Found();
                }
            };
        }
    }
    public bool checkTile()
    {
        if (isPlayerChecked)
            return false;
        else
        {
            if (hasWeapon == true)
            {
                tickerBoard.fulfillingInvestigation(stateMachine.getPlayerTurn());
                setFoundInChild();
            }
            gameObject.GetComponent<SpriteRenderer>().sprite = checkedTile;
            isPlayerChecked = true;
            return true;
        }
    }

    public bool accessWeapon()
    {
        if (hasWeapon == true)
        {
            return true;
        }
        else
            return false;
    }

    void OnMouseDown()
    {
        errorText.Empty();
        if (stateMachine.getGameState() == -2 || stateMachine.getGameState() == 0)
        {
            if (playerOwnedBy == stateMachine.getPlayerTurn())
            {
                (Instantiate(weaponObject, gameObject.transform.position, Quaternion.identity) as Transform).parent = gameObject.transform;
                if (stateMachine.getGameState() == -2 || stateMachine.getGameState() == 0)
                {
                    stateMachine.getConfirmation(true);
                    if (stateMachine.getGameState() == 0)
                        stateMachine.setGameState(100);
                    else
                        stateMachine.setGameState(stateMachine.getGameState() + 1);
                }
                hasWeapon = true;

            }
            else
                errorText.isntYourTile();
        }



        else if (stateMachine.getGameState() == 2)
        {
            if (trapped == false && hasWeapon == false && isStartingSpot == false)
            {
                if (playerOwnedBy == stateMachine.getPlayerTurn())
                {
                    Debug.Log("Activated");
                    trapped = true;
                    if (stateMachine.getPlayerTurn() == 1)
                    {
                        if (gcScript.pathSearch(2) == true && gcScript.pathSearch(3) == true)
                        {
                            tickerBoard.fulfillingTrap(stateMachine.getPlayerTurn());
                            (Instantiate(trapObject, gameObject.transform.position, Quaternion.identity) as Transform).parent = gameObject.transform;
                            stateMachine.setGameState(10);
                        }
                        else
                        {
                            trapped = false;
                            if (playerOwnedBy == 1)
                                errorText.pathBlocker();
                        }
                    }
                    else
                    {
                        if (gcScript.pathSearch(0) == true && gcScript.pathSearch(1) == true)
                        {
                            tickerBoard.fulfillingTrap(stateMachine.getPlayerTurn());
                            (Instantiate(trapObject, gameObject.transform.position, Quaternion.identity) as Transform).parent = gameObject.transform;
                            stateMachine.setGameState(10);
                        }
                        else
                        {
                            trapped = false;
                            if (playerOwnedBy == -1)
                                errorText.pathBlocker();
                        }
                    }
                }
                else
                    errorText.isntYourTile();
            }
            else
            {
                if (playerOwnedBy == stateMachine.getPlayerTurn())
                    errorText.fullSpace();
                else
                    errorText.isntYourTile();
            }
        }
    }


    public void weaponCheck()
    {
        isChecked = true;
        if (hasWeapon)
            stateMachine.setWeaponPathFound(true);
        GameObject leftTile = (tileManager.getTile(collumnNumber-1, rowNumber));
        GameObject rightTile = (tileManager.getTile(collumnNumber +1, rowNumber));
        GameObject northTile = (tileManager.getTile(collumnNumber, rowNumber+1));
        GameObject southTile = (tileManager.getTile(collumnNumber, rowNumber-1));
        if (leftTile != null)
        {
            TileScript leftTS = leftTile.GetComponent<TileScript>();
            if (leftTS.getPlayerOwnedBy() == getPlayerOwnedBy() && leftTS.trapped == false && leftTS.isChecked == false)
            {
                leftTS.weaponCheck();
            }
        }
        if (rightTile != null)
        {
            TileScript rightTS = rightTile.GetComponent<TileScript>();
            if (rightTS.getPlayerOwnedBy() == getPlayerOwnedBy() && rightTS.trapped == false && rightTS.isChecked == false)
            {
                rightTS.weaponCheck();
            }
        }
        if (northTile != null)
        {
            TileScript northTS = northTile.GetComponent<TileScript>();
            if (northTS.getPlayerOwnedBy() == getPlayerOwnedBy() && northTS.trapped == false && northTS.isChecked == false)
            {
                northTS.weaponCheck();
            }
        }
        if (southTile != null)
        {
            TileScript southTS = southTile.GetComponent<TileScript>();
            if (southTS.getPlayerOwnedBy() == getPlayerOwnedBy() && southTS.trapped == false && southTS.isChecked == false)
            {
                southTS.weaponCheck();
            }
        }
       

        /*
         if (collumnNumber-1 > 0)
        {
            GameObject leftTile = (tileManager.getTile(collumnNumber - 1, rowNumber));
            TileScript leftTS = leftTile.GetComponent<TileScript>();
            if (leftTS.getPlayerOwnedBy() == getPlayerOwnedBy() && leftTS.trapped == false && leftTS.isChecked == false)
                leftTS.weaponCheck();
        }
        if (collumnNumber + 1 <= stateMachine.getGameCollumns())
        {
            GameObject rightTile = (tileManager.getTile(collumnNumber + 1, rowNumber));
            TileScript rightTS = rightTile.GetComponent<TileScript>();
            if (rightTS.getPlayerOwnedBy() == getPlayerOwnedBy() && rightTS.trapped == false && rightTS.isChecked == false)
                rightTS.weaponCheck();
        }
        if (rowNumber + 1 <= stateMachine.getGameRows())
        {
            GameObject northTile = (tileManager.getTile(collumnNumber, rowNumber + 1));
            TileScript northTS = northTile.GetComponent<TileScript>();
            if (northTS.getPlayerOwnedBy() == getPlayerOwnedBy() && northTS.trapped == false && northTS.isChecked == false)
                northTS.weaponCheck();
        }
        if (rowNumber - 1 >0)
        {
            GameObject southTile = (tileManager.getTile(collumnNumber, rowNumber - 1));
            TileScript southTS = southTile.GetComponent<TileScript>();
            if (southTS.getPlayerOwnedBy() == getPlayerOwnedBy() && southTS.trapped == false && southTS.isChecked == false)
                southTS.weaponCheck();
        }*/

    }

}
