﻿using UnityEngine;
using System.Collections;

public class TileManager : MonoBehaviour {
    private GameObject[,] grid;
    private StateMachine stateMachine;
    public int collumnSize;
    public int rowSize;
   

	// Use this for initialization
	void Start () {
        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
        stateMachine.setGameRows(rowSize);
        stateMachine.setGameCollumns(collumnSize);

        grid = new GameObject[collumnSize,rowSize];
        GameObject[] objectList = GameObject.FindGameObjectsWithTag("Tile");
        for (int k = 0; k < objectList.Length; k++)
        {
            grid[objectList[k].GetComponent<TileScript>().collumnNumber-1, objectList[k].GetComponent<TileScript>().rowNumber-1] = objectList[k];
            if (objectList[k].GetComponent<TileScript>().rowNumber <= (rowSize / 2))
                objectList[k].GetComponent<TileScript>().setPlayerOwnedBy(1);
            else
                objectList[k].GetComponent<TileScript>().setPlayerOwnedBy(-1); 
        }
       
	
	}
	
	// Update is called once per frame
	void Update () {
     //   Destroy(getTile(1, 3));
       // Destroy(getTile(2, 4));
       // Destroy(getTile(3, 5));
       // Destroy(getTile(4, 6));
       // Destroy(getTile(5, 7));
       // Destroy(getTile(6, 8));
      //  Destroy(getTile(7, 8));
      //  Destroy(getTile(8, 8));
	
	}
    public GameObject getTile(int collumnNumber, int rowNumber)
    {

        collumnNumber--;
        rowNumber--;
        if (collumnNumber < 0 || collumnNumber >= collumnSize || rowNumber < 0 || rowNumber >= rowSize)
            return null;
        else
            return grid[collumnNumber, rowNumber];
    }
}
