﻿using UnityEngine;
using System.Collections;

public class TokenScript : MonoBehaviour {
    private TileManager tileManager;
    private StateMachine stateMachine;
    private TickerboardScript tickerBoard;
    private ErrorTextScript errorText;


	// Use this for initialization
	void Start () {
        GameObject gameController = GameObject.FindWithTag("GameController");
        tickerBoard = GameObject.FindWithTag("Tickerboard").GetComponent<TickerboardScript>();
        errorText = GameObject.FindWithTag("ErrorText").GetComponent<ErrorTextScript>();
        tileManager = gameController.GetComponent<TileManager>();


        stateMachine = gameController.GetComponent<StateMachine>();
	
	}
	
	// Update is called once per frame
	void Update () {
        move();
        if(GetComponentInParent<TileScript>().getIsTrapped() == true)
        {
            tickerBoard.trapDeath(stateMachine.getPlayerTurn());
            GetComponentInParent<TileScript>().setFoundInChild();
            stateMachine.setGameState(10);
            DestroyObject(this.gameObject);
        }
      
	}

    void move()
    {
        if (Input.GetKeyDown("space"))
        {
            //Debug.Log("Look at how many times im being called");
            if (GetComponentInParent<TileScript>().checkTile() == true)
            {
                errorText.Empty();
                if (GetComponentInParent<TileScript>().accessWeapon() == false)
                    tickerBoard.emptyInvestigation(stateMachine.getPlayerTurn());
                stateMachine.setGameState(10);
                DestroyObject(this.gameObject);
                
            }
            else
            {
                if (GetComponentInParent<TileScript>().accessWeapon() == true)
                {
                    errorText.Empty();
                    if(stateMachine.getPlayerTurn() == 1)
                        stateMachine.setGameState(6);
                    else if(stateMachine.getPlayerTurn() == -1)
                        stateMachine.setGameState(8);
                    DestroyObject(this.gameObject);
                }
                else
                    errorText.alreadySearched();

            }


        }
        if (Input.GetKeyDown("up"))
        {
            GameObject newTile;
            int newCollumn = GetComponentInParent<TileScript>().collumnNumber;
            int newRow = GetComponentInParent<TileScript>().rowNumber + 1;
            if (newCollumn > 0 && newCollumn <= stateMachine.getGameCollumns() && newRow > 0 && newRow <= stateMachine.getGameRows())
            {
                newTile = (tileManager.getTile(newCollumn, newRow));
                if (newTile.GetComponent<TileScript>().getPlayerOwnedBy() == (stateMachine.getPlayerTurn() * -1))
                {
                    gameObject.transform.position = newTile.transform.position;
                    gameObject.transform.parent = newTile.transform;
                }
            }

        }
        if (Input.GetKeyDown("down"))
        {
            GameObject newTile;
            int newCollumn = GetComponentInParent<TileScript>().collumnNumber;
            int newRow = GetComponentInParent<TileScript>().rowNumber - 1;
            if (newCollumn > 0 && newCollumn <= stateMachine.getGameCollumns() && newRow > 0 && newRow <= stateMachine.getGameRows())
            {
                newTile = (tileManager.getTile(newCollumn, newRow));
                if (newTile.GetComponent<TileScript>().getPlayerOwnedBy() == (stateMachine.getPlayerTurn() * -1))
                {
                    gameObject.transform.position = newTile.transform.position;
                    gameObject.transform.parent = newTile.transform;
                }
            }

        }
        if (Input.GetKeyDown("left"))
        {
            GameObject newTile;
            int newCollumn = GetComponentInParent<TileScript>().collumnNumber - 1;
            int newRow = GetComponentInParent<TileScript>().rowNumber;
            if (newCollumn > 0 && newCollumn <= stateMachine.getGameCollumns() && newRow > 0 && newRow <= stateMachine.getGameRows())
            {
                newTile = (tileManager.getTile(newCollumn, newRow));
                if (newTile.GetComponent<TileScript>().getPlayerOwnedBy() == (stateMachine.getPlayerTurn() * -1))
                {
                    gameObject.transform.position = newTile.transform.position;
                    gameObject.transform.parent = newTile.transform;
                }
            }

        }
        if (Input.GetKeyDown("right"))
        {
            GameObject newTile;
            int newCollumn = GetComponentInParent<TileScript>().collumnNumber + 1;
            int newRow = GetComponentInParent<TileScript>().rowNumber;
            if (newCollumn > 0 && newCollumn <= stateMachine.getGameCollumns() && newRow > 0 && newRow <= stateMachine.getGameRows())
            {
                newTile = (tileManager.getTile(newCollumn, newRow));
                if (newTile.GetComponent<TileScript>().getPlayerOwnedBy() == (stateMachine.getPlayerTurn() * -1))
                {
                    gameObject.transform.position = newTile.transform.position;
                    gameObject.transform.parent = newTile.transform;
                }
            }

        }
    }
    

}
