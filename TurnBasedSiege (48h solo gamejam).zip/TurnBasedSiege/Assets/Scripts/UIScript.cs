﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIScript : MonoBehaviour
{

    private int deleteMeTellWhatState = 900;

    Text theText;
    private StateMachine stateMachine;
    private GameController gameController;
    private QandAScript qandAScript;
    private TickerboardScript tickerBoard;

    private bool upSwitch = true;
    private bool downSwitch = true;

    private bool yesClicked = false;
    private bool noClicked = false;

    void Start()
    {
        theText = GetComponent<Text>();
        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
        gameController = legameObject.GetComponent<GameController>();
        qandAScript = legameObject.GetComponent<QandAScript>();
        tickerBoard = GameObject.FindWithTag("Tickerboard").GetComponent<TickerboardScript>();
    }

    // Update is called once per frame
    void Update()
    {
        if(stateMachine.getGameState() != deleteMeTellWhatState)
        {
            Debug.Log ("State: " + stateMachine.getGameState());
            deleteMeTellWhatState = stateMachine.getGameState();
        }



        if (stateMachine.getGameState() == -7)
        {
          /*  if (upSwitch)
            {
                gameObject.transform.position += new Vector3(0, 100, 0);
                upSwitch = false;
            }*/
            theText.text = "Press any key to start.";
        }
        else if (stateMachine.getGameState() == -6)
        {
            theText.text = "Player 1 please choose a password. Your password must be a word or phrase under 15 characters. Please refrain from using random letters unless you have agreed upon this with the other player beforehand.";
        }
        else if (stateMachine.getGameState() == -5)
        {
            theText.text = "Is ";
            theText.text += gameController.getPlayer1Password();
            theText.text += " your final password?";
            if (yesClicked == true)
            {
                stateMachine.setGameState(-4);
                yesClicked = false;
            }
            else if (noClicked == true)
            {
                gameController.setPlayer1Password("");
                stateMachine.setGameState(-6);
                noClicked = false;
            }
        }
        else if (stateMachine.getGameState() == -4)
        {
            theText.text = "Player 2 please choose a password. Your password must be a word or phrase under 15 characters. Please refrain from using random letters unless you have agreed upon this with the other player beforehand.";
        }
        else if (stateMachine.getGameState() == -3)
        {
            theText.text = "Is ";
            theText.text += gameController.getPlayer2Password();
            theText.text += " your final password?";
            if (yesClicked == true)
            {
                stateMachine.setGameState(-2);
                yesClicked = false;
            }
            else if (noClicked == true)
            {
                gameController.setPlayer2Password("");
                stateMachine.setGameState(-4);
                noClicked = false;
            }
        }
        else if(stateMachine.getGameState() == -2)
        {
           /* if (downSwitch)
            {
                gameObject.transform.position += new Vector3(0, -100, 0);
                downSwitch = false;
            }*/
            theText.text = "Player 1 please place your unconventional weapon";
        }
        else if(stateMachine.getGameState() == -1)
        {
            theText.text = "Is this your final position?";
            if (yesClicked == true)
            {
                stateMachine.setGameState(0);
                yesClicked = false;
            }
            else if (noClicked == true)
            {
                //erase weapon
                GameObject [] go = GameObject.FindGameObjectsWithTag("Unconventional Weapon");
                for (int i = 0; i < go.Length; i++)
                {
                    if(go[i].transform.parent.GetComponent<TileScript>().playerOwnedBy == stateMachine.getPlayerTurn())
                    {
                        go[i].transform.parent.GetComponent<TileScript>().setHasWeapon(false);
                        Destroy(go[i]);
                    }
                }
                stateMachine.setGameState(-2);
                noClicked = false;
            }
        }
        else if (stateMachine.getGameState() == 0)
        {
            theText.text = "Player 2 please place your unconventional weapon";
        }

        else if (stateMachine.getGameState() == 100)
        {
            theText.text = "Is this your final position?";
            if (yesClicked == true)
            {
                stateMachine.setGameState(10);
                yesClicked = false;
            }
            else if (noClicked == true)
            {
                //erase weapon
                GameObject[] go = GameObject.FindGameObjectsWithTag("Unconventional Weapon");
                for (int i = 0; i < go.Length; i++)
                {
                    if (go[i].transform.parent.GetComponent<TileScript>().playerOwnedBy == stateMachine.getPlayerTurn())
                    {
                        go[i].transform.parent.GetComponent<TileScript>().setHasWeapon(false);
                        Destroy(go[i]);
                    }
                }
                stateMachine.setGameState(0);
                noClicked = false;
            }
        }
       
        else if (stateMachine.getGameState() == 1)
        {
            if(Input.GetKey("p"))
            {
                if (stateMachine.getPlayerTurn() == 1)
                    theText.text = gameController.getPlayer1Password();
                if (stateMachine.getPlayerTurn() == -1)
                    theText.text = gameController.getPlayer2Password();
            }
            else if(!Input.GetKey("p"))
                theText.text = "Press q to set a trap. Press w to ask a question\nPress e to venture to the other side. Press p to see your password";
        }
        else if (stateMachine.getGameState() == 2)
        {
            theText.text = "Click on where you want to set a trap"; //change this to an icon?
        }
        else if (stateMachine.getGameState() == 4)
        {
            theText.text = "Tap (1) or (2) for where you want to start";
        }
        else if (stateMachine.getGameState() == 5)
        {
            theText.text = "Move with the arrow keys. \nPress spacebar to search the current tile for the unconventional weapon. \nDoing so will end your turn as well as running into a trap.";
        }
        else if (stateMachine.getGameState() == 6)
        {
              theText.text = "What is your guess for Player 2's password?";
        }
        else if (stateMachine.getGameState() == 7)
        {
         //  Debug.Log("IM STILL SEVEN" + noClicked);
            theText.text = "Is this your final guess: ";
              theText.text += gameController.getPlayer1PasswordGuess();
          //  theText.text = gameController.get
            yesNoDirectory(10,6);
        }
        else if (stateMachine.getGameState() == 8)
        {
            theText.text = "What is your guess for Player 1's password?";
        }
        else if (stateMachine.getGameState() == 9)
        {
            theText.text = "Is this your final guess?";
            theText.text += gameController.getPlayer2PasswordGuess();
            yesNoDirectory(10, 8);
        }
        else if (stateMachine.getGameState() == 10)
        {
            if (stateMachine.getPlayerTurn() == 1)//PLAYER TURNS AREN'T SWITCHED YET BE CAREFUL. Thats why they are topsy turvy here. bad fix this blah
                theText.text = "Are you ready Player 1?  Press enter for your screen.";
            else
                theText.text = "Are you ready Player 2? Press enter for your screen";
        }
        else if (stateMachine.getGameState() == 11)
        {
            theText.text = "Type in a question to send to Player 2 about their password.  \nPlease refrain from using \"What is your password\" The other player is not obligated to answer that.";
            qandAScript.resetPlayer1Question();
        }
        else if (stateMachine.getGameState() == 12)
        {
            theText.text = "Is this correct: ";
            theText.text += qandAScript.getPlayer1Question();
            yesNoDirectory(13, 11);
        }
        else if (stateMachine.getGameState() == 13)
        {
            theText.text = "Player 1 has asked: ";
            theText.text += qandAScript.getPlayer1Question();
            theText.text += ". \nPlease respond truthfully, the rules say lying disqualifies you.";
            qandAScript.resetPlayer2Answer();
        }
        else if (stateMachine.getGameState() == 14)
        {
            theText.text = "Is this correct: ";
            theText.text += qandAScript.getPlayer2Answer();
            yesNoDirectory(10, 13);
        }

        else if (stateMachine.getGameState() == 15)
        {
            theText.text = "Type in a question to send to Player 1 about their password. \nPlease refrain from using \"What is your password\" \nThe other player is not obligated to answer that.";
            qandAScript.resetPlayer2Question();
        }
        else if (stateMachine.getGameState() == 16)
        {
            theText.text = "Is this correct: ";
            theText.text += qandAScript.getPlayer2Question();
            yesNoDirectory(17, 15);
           
        }
        else if (stateMachine.getGameState() == 17)
        {
            theText.text = "Player 2 has asked: ";
            theText.text += qandAScript.getPlayer2Question();
            theText.text += ". \nPlease respond truthfully, the rules say lying disqualifies you.";
            qandAScript.resetPlayer1Answer();
        }
        else if (stateMachine.getGameState() == 18)
        {
            theText.text = "Is this correct: ";
            theText.text += qandAScript.getPlayer1Answer();
            yesNoDirectory(10, 17);
        }
        else if (stateMachine.getGameState() == 1000 || stateMachine.getGameState() == -1000)
        {
            theText.text = "";
        }


    }

    public void yesNoDirectory(int yesState, int noState)
    {
        

        if (yesClicked == true)
        {
            if (stateMachine.getGameState() == 7 && stateMachine.getPlayerTurn() == 1)
            {
                if (gameController.getPlayer1PasswordGuess() != gameController.getPlayer2Password())
                    tickerBoard.incorrectGuess(stateMachine.getPlayerTurn(), gameController.getPlayer1PasswordGuess());
                gameController.setPlayer1PasswordGuess("");
            }
            else if (stateMachine.getGameState() == 9 && stateMachine.getPlayerTurn() == -1)
            {
                if (gameController.getPlayer2PasswordGuess() != gameController.getPlayer1Password())
                    tickerBoard.incorrectGuess(stateMachine.getPlayerTurn(), gameController.getPlayer2PasswordGuess());
                gameController.setPlayer2PasswordGuess("");
            }

            if(stateMachine.getGameState() == 18)
                tickerBoard.answeredQuestion(stateMachine.getPlayerTurn()*-1, qandAScript.getPlayer1Answer());
            else if (stateMachine.getGameState() == 14)
                tickerBoard.answeredQuestion(stateMachine.getPlayerTurn()*-1, qandAScript.getPlayer2Answer());
            else if(stateMachine.getGameState() == 12)
                tickerBoard.askedQuestion(stateMachine.getPlayerTurn(), qandAScript.getPlayer1Question());
            else if (stateMachine.getGameState() == 16)
                tickerBoard.askedQuestion(stateMachine.getPlayerTurn(), qandAScript.getPlayer2Question());


            stateMachine.setGameState(yesState);
            yesClicked = false;
        }
        else if (noClicked == true)
        {
            if (stateMachine.getGameState() == 7 && stateMachine.getPlayerTurn() == 1)
            {
               // if (gameController.getPlayer1PasswordGuess() != gameController.getPlayer2Password())
                 //   tickerBoard.incorrectGuess(stateMachine.getPlayerTurn(), gameController.getPlayer1PasswordGuess());
                gameController.setPlayer1PasswordGuess("");
            }
            else if (stateMachine.getGameState() == 9 && stateMachine.getPlayerTurn() == -1)
            {
             //   if (gameController.getPlayer2PasswordGuess() != gameController.getPlayer1Password())
               //     tickerBoard.incorrectGuess(stateMachine.getPlayerTurn(), gameController.getPlayer2PasswordGuess());
                gameController.setPlayer2PasswordGuess("");
            }

            stateMachine.setGameState(noState);
            noClicked = false;
        }

    }
    public void clickYes()
    {
        yesClicked = true;
    }
    public void clickNo()
    {
        Debug.Log("Im being clicked no");
        noClicked = true;
        //Debug.Log("Call me lose" + noClicked);
    }
}
