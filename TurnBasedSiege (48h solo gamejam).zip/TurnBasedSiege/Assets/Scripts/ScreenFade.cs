﻿using UnityEngine;
using System.Collections;

public class ScreenFade : MonoBehaviour
{
    private SpriteRenderer sr;
    private StateMachine stateMachine;
    // Use this for initialization
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
        sr.enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        if(stateMachine.getGameState() == 10)
            sr.color = new Color(1f, 1f, 1f, .5f);
        else if (stateMachine.getGameState() < -2 && stateMachine.getGameState() > -10)
            sr.color = new Color(1f, 1f, 1f, 1f);
        else
            sr.color = new Color(1f, 1f, 1f, 0f);

    }
}
