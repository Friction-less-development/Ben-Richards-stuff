﻿using UnityEngine;
using System.Collections;

public class WinObjectScript : MonoBehaviour {
    public int appearAtGameState;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (GameObject.FindWithTag("GameController").GetComponent<StateMachine>().getGameState() == appearAtGameState)
        {
            GetComponent<SpriteRenderer>().enabled = true;
            if (Input.anyKeyDown)
            {
                Application.LoadLevel("Main_Scene");
            }
        }
	
	}
}
