﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour {

    private StateMachine stateMachine;
    private TickerboardScript tickerBoard;
    public Transform[] startingPositions;
    private ErrorTextScript errorText;
    public GameObject Token;
    public string player1Password = "";
    public string player2Password = "";
    public string player1PasswordGuess = "";
    public string player2PasswordGuess = "";
    private bool player1Win = false;
    private bool player2Win = false;


    private bool playerSwitchSwitch = true;



	// Use this for initialization
	void Start () {
        tickerBoard = GameObject.FindWithTag("Tickerboard").GetComponent<TickerboardScript>();
        errorText = GameObject.FindWithTag("ErrorText").GetComponent<ErrorTextScript>();
        stateMachine = gameObject.GetComponent<StateMachine>();
        stateMachine.setGameState(-7);
        setupGame();
       // stateMachine.setPlayerTurn(1);

        
	
	}
	
	// Update is called once per frame
	void Update () {
        if (player1PasswordGuess != "" || player2PasswordGuess != "")
        {
            if (player1PasswordGuess == player2Password)
            {
                player1Win = true;
            }
            else
            {
                player1Win = false;
            }
            if (player2PasswordGuess == player1Password)
            {
                player2Win = true;
            }
            else
            {
                player2Win = false;
            }
            if(stateMachine.getPlayerTurn() == 1)
                stateMachine.setGameState(7);
            else if (stateMachine.getPlayerTurn() == -1)
                stateMachine.setGameState(9);
        }
                
        else
        {
            if (stateMachine.getGameState() == 1000)
            {
                tickerBoard.empty();
            }
            if (stateMachine.getGameState() == -1000)
            {
                tickerBoard.empty();
            }

            if (stateMachine.getGameState() <= 0)
            {
                setupGame();
            }
            if (stateMachine.getGameState() == 1)
            {
                getPlayerMoveChoice();
            }

            if (stateMachine.getGameState() == 4)
            {
                getStartingPosition();
            }
            if (stateMachine.getGameState() == 10)
            {
                checkGuesses();
                playerChange();
            }
        }
	
	}

    void playerChange()
    {
        if(playerSwitchSwitch == true)
        {
            stateMachine.setPlayerTurn(stateMachine.getPlayerTurn() * -1);
            playerSwitchSwitch = false;
        }
        
        if (Input.GetKey("enter") || Input.GetKey("return"))
        {
            stateMachine.setGameState(1);
            playerSwitchSwitch = true;
        }
    }

    void setupGame()
    {
        if (stateMachine.getGameState() == -7)
        {
            if (Input.anyKey)
            {
                stateMachine.setGameState(-6);
            }
        }
        else if (stateMachine.getGameState() == -6)
        {
            stateMachine.setPlayerTurn(1);
            if (player1Password != "")
            {
                stateMachine.setGameState(-5);
            }
        }
        else if (stateMachine.getGameState() == -4)
        {
            stateMachine.setPlayerTurn(-1);
            if (player2Password != "")
            {
                stateMachine.setGameState(-3);
            }
        }
        else if (stateMachine.getGameState() == -2)
            stateMachine.setPlayerTurn(1);
        else if (stateMachine.getGameState() == 0)
        {
            stateMachine.setPlayerTurn(-1);
        }

    }

    void getPlayerMoveChoice()
    {
        if (Input.GetKey("q"))
        {
            tickerBoard.choiceTrap(stateMachine.getPlayerTurn());
            stateMachine.setGameState(2);
        }
        else if (Input.GetKey("w"))
        {
            tickerBoard.choiceQuestion(stateMachine.getPlayerTurn());
            if (stateMachine.getPlayerTurn() == 1)
                stateMachine.setGameState(11);
            else if (stateMachine.getPlayerTurn() == -1)
                stateMachine.setGameState(15);
        }
        else if (Input.GetKey("e"))
        {
            tickerBoard.choiceMove(stateMachine.getPlayerTurn());
            stateMachine.setGameState(4);
        }
    }

    void getStartingPosition()
    {

        foreach (char c in Input.inputString)
        {
            errorText.Empty();
            if(isNum(c))
            {
                int numberVariable = c;
                numberVariable -= 48;
               

                if(stateMachine.getPlayerTurn() == 1)
                {
                    Debug.Log(numberVariable);
                    if (numberVariable == 1 || numberVariable == 2)
                    {
                        numberVariable--;
                        Instantiate(Token, startingPositions[numberVariable].parent.position, Quaternion.identity);
                        GameObject temp = GameObject.FindWithTag("Token");
                        temp.transform.parent = startingPositions[numberVariable].parent;
                        stateMachine.setGameState(5);
                    }
                    else
                        errorText.oneOrTwo();
                }
                else if (stateMachine.getPlayerTurn() == -1)
                {
                    numberVariable += 2;
                    if (numberVariable == 3 || numberVariable == 4)
                    {
                        numberVariable--;
                        Instantiate(Token, startingPositions[numberVariable].parent.position, Quaternion.identity);
                        GameObject temp = GameObject.FindWithTag("Token");
                        temp.transform.parent = startingPositions[numberVariable].parent;
                        stateMachine.setGameState(5);
                    }
                    else
                        errorText.oneOrTwo();
                }
            }
        }

    }

    public bool pathSearch(int startingSpot)
    {
          TileScript ts = startingPositions[startingSpot].GetComponentInParent<TileScript>();
          ts.weaponCheck();
          if (stateMachine.getWeaponPathFound() == false)
          {
              stateMachine.setWeaponPathFound(false);
              GameObject[] objectList = GameObject.FindGameObjectsWithTag("Tile");
              for (int k = 0; k < objectList.Length; k++)
              {
                  objectList[k].GetComponent<TileScript>().isChecked = false;
              }
              return false;
          }
          else
          {
              stateMachine.setWeaponPathFound(false);
              GameObject[] objectList = GameObject.FindGameObjectsWithTag("Tile");
              for (int k = 0; k < objectList.Length; k++)
              {
                  objectList[k].GetComponent<TileScript>().isChecked = false;
              }
              return true;
          }

    }
    private void checkGuesses()
    {
        if (player1Win == true)
            stateMachine.setGameState(1000);
        else if (player2Win == true)
            stateMachine.setGameState(-1000);
       
    }

    public void setPlayer1Password(string set)
    {
        player1Password = set.ToUpper();
    }
    public void setPlayer2Password(string set)
    {
        player2Password = set.ToUpper();
    }
    public void setPlayer1PasswordGuess(string set)
    {
        player1PasswordGuess = set.ToUpper();
    }
    public void setPlayer2PasswordGuess(string set)
    {
        player2PasswordGuess = set.ToUpper();
    }
    public string getPlayer1Password()
    {
        return player1Password;
    }
    public string getPlayer2Password()
    {
        return player2Password;
    }
    public string getPlayer1PasswordGuess()
    {
        return player1PasswordGuess;
    }
    public string getPlayer2PasswordGuess()
    {
        return player2PasswordGuess;
    }

    bool isNum(char c)
    {
        if(c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
            return true;
        else
            return false;
    }

}
