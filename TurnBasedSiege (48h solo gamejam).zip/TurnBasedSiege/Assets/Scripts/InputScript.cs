﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InputScript : MonoBehaviour {
    InputField theInputField;
    Image theImage;
    private StateMachine stateMachine;
    private bool enableSwitch = true;
    public int appearAtState;
    public int disappearAtState;
    public int destroyAtState;

	// Use this for initialization
	void Start () {
        theInputField = GetComponent<InputField>();
        theImage = GetComponent<Image>();
        enableMe(false);

        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
	}
	
	// Update is called once per frame
	void Update () {
        if(stateMachine.getGameState() == appearAtState)
        {
            enableMe(true);
        }
        else if (stateMachine.getGameState() == disappearAtState)
        {
            enableMe(false);
        }
        else if (stateMachine.getGameState() == destroyAtState)
        {
            Destroy(this.gameObject);
        }
	}

    public void enableMe (bool enabled)
    {
        if (enabled != enableSwitch)
        {
            theInputField.enabled = enabled;
            theImage.enabled = enabled;
            foreach (RectTransform child in transform)
            {
                if (child.gameObject.GetComponent<Text>() != null)
                    child.gameObject.GetComponent<Text>().enabled = enabled;
            }
            enableSwitch = enabled;
        }
    }

}
