﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ButtonScript : MonoBehaviour {
    Image theImage;
    Button theButton;
    private StateMachine stateMachine;

	// Use this for initialization
	void Start () {
        theImage = GetComponent<Image>();
        theButton = GetComponent<Button>();

        GameObject legameObject;
        legameObject = GameObject.FindWithTag("GameController");
        stateMachine = legameObject.GetComponent<StateMachine>();
	
	}
	
	// Update is called once per frame
	void Update () {
        if(stateMachine.setConfirmation() == true)
        {
            theImage.enabled = true;
            theButton.enabled = true;
        }
	
	}
}
