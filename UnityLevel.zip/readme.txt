Textures and crystal model not done by me.

Click switches to make things happen.
Spacebar jumps.
Arrow keys walk.