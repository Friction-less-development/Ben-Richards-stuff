<?php
  // Define database connection constants
  define('DB_HOST','127.0.0.1');
  define('DB_USER','root');
  define('DB_PASSWORD', '');
  define('DB_NAME', 'pickpic');

//  define('CON_STRING', 'mysql:host=classmysql.engr.oregonstate.edu;dname=cs340_youngsam');
?>
