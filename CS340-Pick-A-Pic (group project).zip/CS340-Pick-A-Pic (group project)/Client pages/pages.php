<?php
//$content holds a 2D array with keys being menu names and values being an array with a subtitle, and content
	$content = array(
		"Sign up" => "Signup.php",
		"List Users" => "listUsers.php",
    "Log In" => "logIn.php", "My Uploads" => "MyUploads.php", "Home" => "Home.php", "Upload" => "Upload.php", "Search" => "Search.php")
;

?>
